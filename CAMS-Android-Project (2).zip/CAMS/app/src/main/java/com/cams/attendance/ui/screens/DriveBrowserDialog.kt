package com.cams.attendance.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.cams.attendance.data.sync.DriveBackupFileInfo
import com.cams.attendance.data.sync.DriveFolderInfo
import com.cams.attendance.data.sync.DriveSyncManager
import com.cams.attendance.ui.theme.DataFont
import com.cams.attendance.ui.theme.Ink
import com.cams.attendance.ui.theme.Marigold
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

private data class Breadcrumb(val id: String, val name: String)

/**
 * @param forRestore true = browsing to pick a backup file to restore;
 *                   false = browsing to pick/create a folder to back up into.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DriveBrowserDialog(
    drive: DriveSyncManager,
    forRestore: Boolean,
    onDismiss: () -> Unit,
    onFolderChosen: (DriveFolderInfo) -> Unit = {},
    onFileChosen: (DriveBackupFileInfo) -> Unit = {}
) {
    val scope = rememberCoroutineScope()
    var trail by remember { mutableStateOf(listOf(Breadcrumb("root", "My Drive"))) }
    var folders by remember { mutableStateOf<List<DriveFolderInfo>>(emptyList()) }
    var files by remember { mutableStateOf<List<DriveBackupFileInfo>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var showNewFolderDialog by remember { mutableStateOf(false) }

    fun load(folderId: String) {
        loading = true
        error = null
        scope.launch {
            try {
                folders = drive.listFolders(folderId)
                files = if (forRestore) drive.listBackupFiles(folderId) else emptyList()
            } catch (e: Exception) {
                error = e.message ?: "Couldn't load this folder"
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(Unit) { load(trail.last().id) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.fillMaxWidth().heightIn(min = 400.dp, max = 560.dp).padding(16.dp)) {
                Text(
                    if (forRestore) "Choose a backup to restore" else "Choose a folder to back up into",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))

                // Breadcrumb trail
                Row(Modifier.fillMaxWidth()) {
                    trail.forEachIndexed { i, crumb ->
                        TextButton(onClick = {
                            trail = trail.subList(0, i + 1)
                            load(crumb.id)
                        }) {
                            Text(crumb.name, style = MaterialTheme.typography.labelMedium)
                        }
                        if (i < trail.lastIndex) Text("/", modifier = Modifier.padding(top = 12.dp))
                    }
                }
                Spacer(Modifier.height(8.dp))

                Box(Modifier.weight(1f)) {
                    when {
                        loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = Marigold)
                        }
                        error != null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(error ?: "", color = MaterialTheme.colorScheme.error)
                        }
                        folders.isEmpty() && files.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(if (forRestore) "No backups found here" else "No subfolders here yet")
                        }
                        else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            items(folders, key = { it.id }) { folder ->
                                ListItem(
                                    headlineContent = { Text(folder.name) },
                                    leadingContent = { Icon(Icons.Filled.Folder, contentDescription = null, tint = Marigold) },
                                    modifier = Modifier.clickable {
                                        trail = trail + Breadcrumb(folder.id, folder.name)
                                        load(folder.id)
                                    }
                                )
                            }
                            if (forRestore) {
                                items(files, key = { it.id }) { file ->
                                    val fmt = remember { SimpleDateFormat("MMM d, yyyy HH:mm", Locale.getDefault()) }
                                    ListItem(
                                        headlineContent = { Text(file.name) },
                                        supportingContent = {
                                            Text(fmt.format(Date(file.modifiedTime)), fontFamily = DataFont)
                                        },
                                        leadingContent = { Icon(Icons.Filled.Description, contentDescription = null) },
                                        modifier = Modifier.clickable { onFileChosen(file) }
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    if (!forRestore) {
                        OutlinedButton(onClick = { showNewFolderDialog = true }) {
                            Icon(Icons.Filled.CreateNewFolder, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("New folder")
                        }
                    } else {
                        Spacer(Modifier.width(1.dp))
                    }
                    Row {
                        TextButton(onClick = onDismiss) { Text("Cancel") }
                        if (!forRestore) {
                            Spacer(Modifier.width(4.dp))
                            Button(
                                onClick = { onFolderChosen(trail.last().let { DriveFolderInfo(it.id, it.name) }) },
                                colors = ButtonDefaults.buttonColors(containerColor = Marigold, contentColor = Ink)
                            ) { Text("Use this folder") }
                        }
                    }
                }
            }
        }
    }

    if (showNewFolderDialog) {
        var name by remember { mutableStateOf("CAMS Backups") }
        AlertDialog(
            onDismissRequest = { showNewFolderDialog = false },
            title = { Text("New folder") },
            text = {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Folder name") }, singleLine = true)
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        val created = drive.createFolder(name, trail.last().id)
                        trail = trail + Breadcrumb(created.id, created.name)
                        showNewFolderDialog = false
                        load(created.id)
                    }
                }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showNewFolderDialog = false }) { Text("Cancel") } }
        )
    }
}
