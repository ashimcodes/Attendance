package com.cams.attendance.data.sync

import android.content.Context
import android.content.Intent
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import com.google.api.services.drive.DriveScopes

/**
 * Wraps classic Google Sign-In (play-services-auth) rather than Firebase Authentication.
 * Rationale: this app doesn't use a Firebase backend (Firestore/Realtime DB) — data sync
 * goes straight to the signed-in user's own Google Drive. Firebase Auth would require an
 * additional Firebase project + google-services.json for no functional benefit here, since
 * what we actually need is a Google account + an OAuth token scoped for Drive access, which
 * GoogleSignInClient already provides directly.
 */
object GoogleAuthManager {

    private val driveScope = Scope(DriveScopes.DRIVE_FILE)
    private val driveAppDataScope = Scope(DriveScopes.DRIVE_APPDATA)

    fun client(context: Context): GoogleSignInClient {
        val options = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(driveScope, driveAppDataScope)
            .build()
        return GoogleSignIn.getClient(context, options)
    }

    fun signInIntent(context: Context): Intent = client(context).signInIntent

    fun lastSignedInAccount(context: Context): GoogleSignInAccount? =
        GoogleSignIn.getLastSignedInAccount(context)

    fun hasDriveScopes(account: GoogleSignInAccount, context: Context): Boolean =
        GoogleSignIn.hasPermissions(account, driveScope, driveAppDataScope)

    fun signOut(context: Context, onComplete: () -> Unit) {
        client(context).signOut().addOnCompleteListener { onComplete() }
    }

    fun handleSignInResult(data: Intent?): GoogleSignInAccount? {
        return try {
            com.google.android.gms.auth.api.signin.GoogleSignIn
                .getSignedInAccountFromIntent(data)
                .getResult(com.google.android.gms.common.api.ApiException::class.java)
        } catch (e: Exception) {
            null
        }
    }
}
