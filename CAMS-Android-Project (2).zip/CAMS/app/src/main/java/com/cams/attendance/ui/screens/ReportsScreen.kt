package com.cams.attendance.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cams.attendance.data.Repository
import com.cams.attendance.data.entity.AttendanceStatus
import com.cams.attendance.data.entity.ClassEntity
import com.cams.attendance.ui.components.AuroraBackground
import com.cams.attendance.ui.components.GlassPanel
import com.cams.attendance.ui.theme.DataFont
import com.cams.attendance.ui.theme.Ink
import com.cams.attendance.ui.theme.Marigold
import com.cams.attendance.ui.theme.Parchment
import com.cams.attendance.util.CsvExporter
import com.cams.attendance.util.PdfExporter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(repo: Repository) {
    val classes by repo.classes().collectAsState(initial = emptyList())
    var selectedClass by remember { mutableStateOf<ClassEntity?>(null) }
    var classMenuOpen by remember { mutableStateOf(false) }
    var from by remember { mutableStateOf(firstOfMonth()) }
    var to by remember { mutableStateOf(today()) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var snackMsg by remember { mutableStateOf<String?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(classes) { if (selectedClass == null) selectedClass = classes.firstOrNull() }

    var rows by remember { mutableStateOf<List<ReportRow>>(emptyList()) }

    suspend fun runReport() {
        val cls = selectedClass ?: return
        val studentsList = repo.studentsByClass(cls.id)
        val list = studentsList.first()
        val records = repo.reportForClass(cls.id, from, to)
        rows = list.map { s ->
            val studentRecords = records.filter { it.studentId == s.id }
            val present = studentRecords.count { it.status == AttendanceStatus.PRESENT }
            val absent = studentRecords.count { it.status == AttendanceStatus.ABSENT }
            val late = studentRecords.count { it.status == AttendanceStatus.LATE }
            val total = studentRecords.size
            val pct = if (total > 0) (present * 100 / total) else 0
            ReportRow(s.fullName, s.rollNumber, present, absent, late, pct)
        }
    }

    LaunchedEffect(selectedClass, from, to) { runReport() }

    Box(Modifier.fillMaxSize()) {
        AuroraBackground(Modifier.fillMaxSize())

        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snackbarHostState) }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
                Text("Attendance Reports", style = MaterialTheme.typography.headlineSmall, color = Parchment)
                Spacer(Modifier.height(12.dp))

                Box {
                    OutlinedButton(
                        onClick = { classMenuOpen = true },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Parchment)
                    ) {
                        Text(selectedClass?.name ?: "Select class")
                    }
                    DropdownMenu(expanded = classMenuOpen, onDismissRequest = { classMenuOpen = false }) {
                        classes.forEach { c ->
                            DropdownMenuItem(text = { Text(c.name) }, onClick = { selectedClass = c; classMenuOpen = false })
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { pickDate(context, from) { from = it } },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Parchment)
                    ) { Text("From: $from", fontFamily = DataFont) }
                    OutlinedButton(
                        onClick = { pickDate(context, to) { to = it } },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Parchment)
                    ) { Text("To: $to", fontFamily = DataFont) }
                }

                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            val cls = selectedClass ?: return@Button
                            val msg = CsvExporter.export(
                                context, "attendance_${cls.name.replace(" ", "_")}_${from}_$to.csv",
                                listOf("Student", "Roll No", "Present", "Absent", "Late", "Attendance %"),
                                rows.map { listOf(it.name, it.roll, it.present.toString(), it.absent.toString(), it.late.toString(), "${it.pct}%") }
                            )
                            snackMsg = msg
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Marigold, contentColor = Ink)
                    ) { Text("Export CSV") }

                    Button(
                        onClick = {
                            val cls = selectedClass ?: return@Button
                            val msg = PdfExporter.export(
                                context, "attendance_${cls.name.replace(" ", "_")}_${from}_$to.pdf",
                                "Attendance Report — ${cls.name} ($from to $to)",
                                listOf("Student", "Roll", "Pres.", "Abs.", "Late", "%"),
                                rows.map { listOf(it.name, it.roll, it.present.toString(), it.absent.toString(), it.late.toString(), "${it.pct}%") }
                            )
                            snackMsg = msg
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Marigold, contentColor = Ink)
                    ) { Text("Export PDF") }
                }

                snackMsg?.let {
                    LaunchedEffect(it) { snackbarHostState.showSnackbar(it); snackMsg = null }
                }

                Spacer(Modifier.height(16.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(rows) { r ->
                        GlassPanel {
                            Row(
                                Modifier.fillMaxWidth().padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        r.name,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Parchment
                                    )
                                    Text(
                                        "Roll ${r.roll}",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontFamily = DataFont,
                                        color = Parchment.copy(alpha = 0.65f)
                                    )
                                }
                                Text(
                                    "P:${r.present} A:${r.absent} L:${r.late} · ${r.pct}%",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontFamily = DataFont,
                                    color = Marigold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

data class ReportRow(val name: String, val roll: String, val present: Int, val absent: Int, val late: Int, val pct: Int)

private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
private fun firstOfMonth(): String {
    val cal = Calendar.getInstance()
    cal.set(Calendar.DAY_OF_MONTH, 1)
    return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
}

private fun pickDate(context: android.content.Context, current: String, onPicked: (String) -> Unit) {
    val cal = Calendar.getInstance()
    val parts = current.split("-").map { it.toInt() }
    cal.set(parts[0], parts[1] - 1, parts[2])
    DatePickerDialog(context, { _, y, m, d ->
        onPicked(String.format("%04d-%02d-%02d", y, m + 1, d))
    }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
}
