package com.cams.attendance

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.fragment.app.FragmentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.cams.attendance.data.AppDatabase
import com.cams.attendance.data.Repository
import com.cams.attendance.data.entity.User
import com.cams.attendance.ui.Routes
import com.cams.attendance.ui.theme.Marigold
import com.cams.attendance.ui.screens.*
import com.cams.attendance.ui.theme.CAMSTheme

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.getInstance(applicationContext)
        val repo = Repository(db, applicationContext)

        setContent {
            CAMSTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    CamsApp(repo)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CamsApp(repo: Repository) {
    val navController = rememberNavController()
    var currentUser by remember { mutableStateOf<User?>(null) }

    if (currentUser == null) {
        LoginScreen(repo) { user -> currentUser = user }
        return
    }

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val hideOuterChrome = currentRoute?.startsWith("swipe_attendance") == true

    Scaffold(
        topBar = {
            if (!hideOuterChrome) {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            SealMark()
                            Spacer(Modifier.width(10.dp))
                            Text(
                                "CAMS",
                                style = MaterialTheme.typography.headlineSmall,
                                fontFamily = com.cams.attendance.ui.theme.DisplayFont
                            )
                        }
                    },
                    navigationIcon = {
                        if (navController.previousBackStackEntry != null) {
                            IconButton(onClick = { navController.popBackStack() }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = {
                            currentUser = null
                            navController.navigate(Routes.DASHBOARD) {
                                popUpTo(0)
                            }
                        }) {
                            Icon(Icons.Filled.Logout, contentDescription = "Log out")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = com.cams.attendance.ui.theme.Ink,
                        titleContentColor = com.cams.attendance.ui.theme.Parchment,
                        navigationIconContentColor = com.cams.attendance.ui.theme.Parchment,
                        actionIconContentColor = com.cams.attendance.ui.theme.Parchment
                    )
                )
            }
        }
    ) { padding ->
        Box(Modifier.padding(if (hideOuterChrome) PaddingValues(0.dp) else padding)) {
            NavHost(navController = navController, startDestination = Routes.DASHBOARD) {
                composable(Routes.DASHBOARD) {
                    val user = currentUser
                    if (user != null) {
                        DashboardScreen(repo, user) { route -> navController.navigate(route) }
                    }
                }
                composable(Routes.STUDENTS) { StudentsScreen(repo) }
                composable(Routes.TEACHERS) { TeachersScreen(repo) }
                composable(Routes.CLASSES) { ClassesScreen(repo) }
                composable(Routes.ATTENDANCE) {
                    val user = currentUser
                    if (user != null) AttendanceScreen(repo, user)
                }
                composable(Routes.REPORTS) { ReportsScreen(repo) }
                composable(Routes.ADMIN) { AdminScreen(repo) }
                composable(Routes.SETTINGS) { SettingsScreen() }
                composable(Routes.SWIPE_FILTERS) {
                    SwipeFilterScreen(repo) { route -> navController.navigate(route) }
                }
                composable(
                    Routes.SWIPE_ATTENDANCE,
                    arguments = listOf(
                        navArgument("classId") { type = NavType.LongType },
                        navArgument("date") { type = NavType.StringType },
                        navArgument("subjectId") { type = NavType.LongType }
                    )
                ) { entry ->
                    val user = currentUser
                    val classId = entry.arguments?.getLong("classId") ?: 0L
                    val date = entry.arguments?.getString("date") ?: ""
                    val subjectIdRaw = entry.arguments?.getLong("subjectId") ?: 0L
                    if (user != null) {
                        SwipeAttendanceScreen(
                            repo = repo,
                            user = user,
                            classId = classId,
                            dateStr = date,
                            subjectId = if (subjectIdRaw == 0L) null else subjectIdRaw,
                            onFinishToDashboard = {
                                navController.navigate(Routes.DASHBOARD) { popUpTo(Routes.DASHBOARD) { inclusive = true } }
                            },
                            onEditManually = {
                                navController.navigate(Routes.ATTENDANCE)
                            }
                        )
                    }
                }
            }
        }
    }
}

/** A small wax-seal-style emblem used as the app's brand mark. */
@Composable
private fun SealMark() {
    Box(
        Modifier.size(30.dp).clip(CircleShape).background(Marigold),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "C",
            color = com.cams.attendance.ui.theme.Ink,
            fontFamily = com.cams.attendance.ui.theme.DisplayFont,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium
        )
    }
}
