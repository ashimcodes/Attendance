package com.cams.attendance.data.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.cams.attendance.data.AppDatabase

class SyncWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        if (!SyncPrefs.isAutoSyncEnabled(applicationContext)) return Result.success()

        val account = GoogleAuthManager.lastSignedInAccount(applicationContext)
            ?: return Result.success() // not signed in — nothing to do, not a failure

        return try {
            SyncPrefs.setStatus(applicationContext, SyncStatus.SYNCING)

            val dbFile = applicationContext.getDatabasePath("cams.db")
            // Ensure any pending writes are flushed to disk before reading the file.
            AppDatabase.getInstance(applicationContext).openHelper.writableDatabase

            val dbBytes = dbFile.readBytes()
            val checksum = CryptoUtil.sha256(dbBytes)

            val drive = DriveSyncManager(applicationContext, account)
            val key = drive.getOrCreateSyncKey()
            val encrypted = CryptoUtil.encrypt(dbBytes, key)
            drive.uploadAutoBackup(encrypted, checksum)

            SyncPrefs.setLastChecksum(applicationContext, checksum)
            SyncPrefs.setLastSyncTime(applicationContext, System.currentTimeMillis())
            SyncPrefs.setStatus(applicationContext, SyncStatus.SYNCED)
            SyncPrefs.setLastError(applicationContext, null)
            Result.success()
        } catch (e: Exception) {
            SyncPrefs.setStatus(applicationContext, SyncStatus.FAILED)
            SyncPrefs.setLastError(applicationContext, e.message ?: "Unknown error")
            Result.retry()
        }
    }
}
