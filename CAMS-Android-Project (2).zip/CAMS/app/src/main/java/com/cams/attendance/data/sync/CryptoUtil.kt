package com.cams.attendance.data.sync

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * AES-256-GCM encryption for backup files.
 *
 * Important design note: the key is NOT stored in the Android Keystore. A
 * Keystore key is device-bound and non-exportable by design — it would make
 * a backup encrypted on one device permanently undecryptable on any other
 * device (or after a reinstall), which defeats the entire point of cloud
 * restore. Instead, the key itself is generated once and stored as a small
 * file inside the signed-in Google account's Drive `appDataFolder` — storage
 * that's private to this app and that account, invisible in the user's normal
 * Drive view and to other apps. Any device signed into the same account can
 * fetch that key after sign-in and decrypt backups made on any other device.
 */
object CryptoUtil {
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val GCM_TAG_BITS = 128
    private const val KEY_SIZE_BYTES = 32 // 256-bit

    fun generateKey(): ByteArray {
        val bytes = ByteArray(KEY_SIZE_BYTES)
        SecureRandom().nextBytes(bytes)
        return bytes
    }

    fun encodeKey(keyBytes: ByteArray): String = Base64.encodeToString(keyBytes, Base64.NO_WRAP)
    fun decodeKey(encoded: String): ByteArray = Base64.decode(encoded, Base64.NO_WRAP)

    fun encrypt(plainBytes: ByteArray, keyBytes: ByteArray): ByteArray {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        val keySpec = SecretKeySpec(keyBytes, "AES")
        cipher.init(Cipher.ENCRYPT_MODE, keySpec)
        val iv = cipher.iv
        val cipherText = cipher.doFinal(plainBytes)

        val out = java.io.ByteArrayOutputStream()
        val ivLen = iv.size
        out.write(byteArrayOf((ivLen shr 24).toByte(), (ivLen shr 16).toByte(), (ivLen shr 8).toByte(), ivLen.toByte()))
        out.write(iv)
        out.write(cipherText)
        return out.toByteArray()
    }

    fun decrypt(encryptedBytes: ByteArray, keyBytes: ByteArray): ByteArray {
        val ivLen = ((encryptedBytes[0].toInt() and 0xFF) shl 24) or
            ((encryptedBytes[1].toInt() and 0xFF) shl 16) or
            ((encryptedBytes[2].toInt() and 0xFF) shl 8) or
            (encryptedBytes[3].toInt() and 0xFF)
        val iv = encryptedBytes.copyOfRange(4, 4 + ivLen)
        val cipherText = encryptedBytes.copyOfRange(4 + ivLen, encryptedBytes.size)

        val cipher = Cipher.getInstance(TRANSFORMATION)
        val keySpec = SecretKeySpec(keyBytes, "AES")
        cipher.init(Cipher.DECRYPT_MODE, keySpec, GCMParameterSpec(GCM_TAG_BITS, iv))
        return cipher.doFinal(cipherText)
    }

    fun sha256(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        return digest.joinToString("") { "%02x".format(it) }
    }
}
