package com.cams.attendance.data.sync

import android.content.Context
import android.content.Intent
import com.cams.attendance.MainActivity
import com.cams.attendance.data.AppDatabase
import java.io.File

object BackupInstaller {

    /** Overwrites the local database file with [bytes] and clears any stale WAL/SHM journals. */
    fun installDatabaseFile(context: Context, bytes: ByteArray) {
        AppDatabase.closeInstance()
        val dbFile = context.getDatabasePath("cams.db")
        dbFile.parentFile?.mkdirs()
        dbFile.writeBytes(bytes)
        File(dbFile.path + "-wal").delete()
        File(dbFile.path + "-shm").delete()
        File(dbFile.path + "-journal").delete()
    }

    /** Restarts the app at the dashboard/login so Room reinitializes against the new file. */
    fun restartApp(context: Context) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        context.startActivity(intent)
        if (context is android.app.Activity) {
            context.finish()
        }
        Runtime.getRuntime().exit(0)
    }
}
