package com.cams.attendance.data.sync

import android.content.Context

enum class SyncStatus { IDLE, SYNCING, SYNCED, FAILED }

object SyncPrefs {
    private const val FILE = "cams_sync_prefs"
    private const val KEY_AUTO_SYNC_ENABLED = "auto_sync_enabled"
    private const val KEY_LAST_SYNC_TIME = "last_sync_time"
    private const val KEY_LAST_SYNC_STATUS = "last_sync_status"
    private const val KEY_LAST_LOCAL_CHANGE_TIME = "last_local_change_time"
    private const val KEY_LAST_MANUAL_BACKUP_TIME = "last_manual_backup_time"
    private const val KEY_LAST_ERROR = "last_error"
    private const val KEY_DB_CHECKSUM = "last_uploaded_checksum"

    private fun prefs(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun isAutoSyncEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_AUTO_SYNC_ENABLED, true)
    fun setAutoSyncEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_AUTO_SYNC_ENABLED, enabled).apply()
    }

    fun getLastSyncTime(context: Context): Long = prefs(context).getLong(KEY_LAST_SYNC_TIME, 0L)
    fun setLastSyncTime(context: Context, time: Long) {
        prefs(context).edit().putLong(KEY_LAST_SYNC_TIME, time).apply()
    }

    fun getStatus(context: Context): SyncStatus =
        SyncStatus.entries.find { it.name == prefs(context).getString(KEY_LAST_SYNC_STATUS, SyncStatus.IDLE.name) }
            ?: SyncStatus.IDLE

    fun setStatus(context: Context, status: SyncStatus) {
        prefs(context).edit().putString(KEY_LAST_SYNC_STATUS, status.name).apply()
    }

    fun touchLocalChange(context: Context) {
        prefs(context).edit().putLong(KEY_LAST_LOCAL_CHANGE_TIME, System.currentTimeMillis()).apply()
    }
    fun getLastLocalChangeTime(context: Context): Long = prefs(context).getLong(KEY_LAST_LOCAL_CHANGE_TIME, 0L)

    fun getLastManualBackupTime(context: Context): Long = prefs(context).getLong(KEY_LAST_MANUAL_BACKUP_TIME, 0L)
    fun setLastManualBackupTime(context: Context, time: Long) {
        prefs(context).edit().putLong(KEY_LAST_MANUAL_BACKUP_TIME, time).apply()
    }

    fun setLastError(context: Context, message: String?) {
        prefs(context).edit().putString(KEY_LAST_ERROR, message).apply()
    }
    fun getLastError(context: Context): String? = prefs(context).getString(KEY_LAST_ERROR, null)

    fun setLastChecksum(context: Context, checksum: String) {
        prefs(context).edit().putString(KEY_DB_CHECKSUM, checksum).apply()
    }
    fun getLastChecksum(context: Context): String? = prefs(context).getString(KEY_DB_CHECKSUM, null)

    /** True if it's been more than [days] since the last successful sync/backup of any kind. */
    fun isBackupOverdue(context: Context, days: Int = 7): Boolean {
        val last = maxOf(getLastSyncTime(context), getLastManualBackupTime(context))
        if (last == 0L) return true
        val elapsedDays = (System.currentTimeMillis() - last) / (1000L * 60 * 60 * 24)
        return elapsedDays >= days
    }
}
