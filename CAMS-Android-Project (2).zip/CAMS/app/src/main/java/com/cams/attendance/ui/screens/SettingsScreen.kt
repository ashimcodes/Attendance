package com.cams.attendance.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cams.attendance.data.sync.*
import com.cams.attendance.ui.components.AuroraBackground
import com.cams.attendance.ui.components.GlassPanel
import com.cams.attendance.ui.theme.Cinnabar
import com.cams.attendance.ui.theme.DataFont
import com.cams.attendance.ui.theme.Ink
import com.cams.attendance.ui.theme.Marigold
import com.cams.attendance.ui.theme.Parchment
import com.cams.attendance.ui.theme.Sage
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

private enum class BusyMode { NONE, SIGNING_IN, BACKING_UP, RESTORING }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var account by remember { mutableStateOf(GoogleAuthManager.lastSignedInAccount(context)) }
    var autoSyncEnabled by remember { mutableStateOf(SyncPrefs.isAutoSyncEnabled(context)) }
    var syncStatus by remember { mutableStateOf(SyncPrefs.getStatus(context)) }
    var lastSyncTime by remember { mutableStateOf(SyncPrefs.getLastSyncTime(context)) }
    var busy by remember { mutableStateOf(BusyMode.NONE) }
    var statusMsg by remember { mutableStateOf<String?>(null) }
    var showBackupBrowser by remember { mutableStateOf(false) }
    var showRestoreBrowser by remember { mutableStateOf(false) }
    var showRestoreConfirm by remember { mutableStateOf<DriveBackupFileInfo?>(null) }
    var showCloudFoundPrompt by remember { mutableStateOf(false) }

    val signInLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        busy = BusyMode.NONE
        val acc = GoogleAuthManager.handleSignInResult(result.data)
        if (acc != null) {
            account = acc
            statusMsg = "Signed in as ${acc.email}"
            scope.launch {
                try {
                    val drive = DriveSyncManager(context, acc)
                    val remoteTime = drive.getAutoBackupModifiedTime()
                    if (remoteTime != null) showCloudFoundPrompt = true
                } catch (_: Exception) { }
            }
        } else {
            statusMsg = "Sign-in was cancelled or failed"
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            syncStatus = SyncPrefs.getStatus(context)
            lastSyncTime = SyncPrefs.getLastSyncTime(context)
            kotlinx.coroutines.delay(2000)
        }
    }

    val overdue = remember(lastSyncTime) { SyncPrefs.isBackupOverdue(context) }

    Box(Modifier.fillMaxSize()) {
        AuroraBackground(Modifier.fillMaxSize())

        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text("Settings", style = MaterialTheme.typography.headlineSmall, color = Parchment)
            Spacer(Modifier.height(16.dp))

            GlassPanel(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(44.dp).clip(CircleShape).background(Marigold),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.AccountCircle, contentDescription = null, tint = Ink)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                account?.displayName ?: "Not signed in",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = Parchment
                            )
                            Text(
                                account?.email ?: "Sign in to enable cloud backup & sync",
                                style = MaterialTheme.typography.bodySmall,
                                color = Parchment.copy(alpha = 0.65f)
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    if (account == null) {
                        Button(
                            onClick = {
                                busy = BusyMode.SIGNING_IN
                                signInLauncher.launch(GoogleAuthManager.signInIntent(context))
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Marigold, contentColor = Ink)
                        ) {
                            if (busy == BusyMode.SIGNING_IN) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Ink, strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Filled.Login, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("Sign in with Google")
                            }
                        }
                    } else {
                        OutlinedButton(
                            onClick = {
                                GoogleAuthManager.signOut(context) {
                                    account = null
                                    statusMsg = "Signed out"
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Parchment)
                        ) { Text("Sign out") }
                    }
                }
            }

            if (account != null) {
                Spacer(Modifier.height(16.dp))

                GlassPanel(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Cloud Sync", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Parchment)
                            SyncStatusBadge(syncStatus)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            if (lastSyncTime > 0) "Last synced: ${formatTime(lastSyncTime)}" else "Never synced yet",
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = DataFont,
                            color = Parchment.copy(alpha = 0.65f)
                        )
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Auto-sync", color = Parchment, style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = autoSyncEnabled,
                                onCheckedChange = {
                                    autoSyncEnabled = it
                                    SyncPrefs.setAutoSyncEnabled(context, it)
                                },
                                colors = SwitchDefaults.colors(checkedTrackColor = Marigold)
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = {
                                SyncTrigger.syncNow(context)
                                syncStatus = SyncStatus.SYNCING
                                statusMsg = "Sync started"
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Marigold, contentColor = Ink)
                        ) {
                            Icon(Icons.Filled.Sync, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Sync Now")
                        }
                    }
                }

                if (overdue) {
                    Spacer(Modifier.height(12.dp))
                    GlassPanel(modifier = Modifier.fillMaxWidth(), tint = Marigold, borderAlpha = 0.7f) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Warning, contentDescription = null, tint = Marigold)
                            Spacer(Modifier.width(10.dp))
                            Text(
                                "It's been a while since your last backup. Consider backing up now.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Parchment
                            )
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))
                Text("Manual Backup", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Parchment)
                Spacer(Modifier.height(8.dp))

                GlassPanel(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(
                            "Save an encrypted backup to a folder you choose in your Drive, or restore from one.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Parchment.copy(alpha = 0.7f)
                        )
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { showBackupBrowser = true },
                                enabled = busy == BusyMode.NONE,
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Marigold, contentColor = Ink)
                            ) { Text("Online Backup") }
                            OutlinedButton(
                                onClick = { showRestoreBrowser = true },
                                enabled = busy == BusyMode.NONE,
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Parchment)
                            ) { Text("Restore Backup") }
                        }
                        if (busy == BusyMode.BACKING_UP || busy == BusyMode.RESTORING) {
                            Spacer(Modifier.height(12.dp))
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Marigold)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                if (busy == BusyMode.BACKING_UP) "Uploading backup…" else "Downloading & verifying…",
                                style = MaterialTheme.typography.labelSmall,
                                color = Parchment.copy(alpha = 0.7f)
                            )
                        }
                    }
                }
            }

            statusMsg?.let { msg ->
                Spacer(Modifier.height(12.dp))
                Text(msg, style = MaterialTheme.typography.bodySmall, color = Marigold)
            }
        }
    }

    if (showBackupBrowser && account != null) {
        DriveBrowserDialog(
            drive = DriveSyncManager(context, account!!),
            forRestore = false,
            onDismiss = { showBackupBrowser = false },
            onFolderChosen = { folder ->
                showBackupBrowser = false
                busy = BusyMode.BACKING_UP
                scope.launch {
                    try {
                        val drive = DriveSyncManager(context, account!!)
                        val dbFile = context.getDatabasePath("cams.db")
                        val bytes = dbFile.readBytes()
                        val checksum = CryptoUtil.sha256(bytes)
                        val key = drive.getOrCreateSyncKey()
                        val encrypted = CryptoUtil.encrypt(bytes, key)
                        val fileName = "cams_backup_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.camsbackup"
                        drive.uploadManualBackup(folder.id, fileName, encrypted, checksum)
                        SyncPrefs.setLastManualBackupTime(context, System.currentTimeMillis())
                        statusMsg = "Backup saved to ${folder.name}"
                    } catch (e: Exception) {
                        statusMsg = "Backup failed: ${e.message}"
                    } finally {
                        busy = BusyMode.NONE
                    }
                }
            }
        )
    }

    if (showRestoreBrowser && account != null) {
        DriveBrowserDialog(
            drive = DriveSyncManager(context, account!!),
            forRestore = true,
            onDismiss = { showRestoreBrowser = false },
            onFileChosen = { file ->
                showRestoreBrowser = false
                showRestoreConfirm = file
            }
        )
    }

    showRestoreConfirm?.let { file ->
        AlertDialog(
            onDismissRequest = { showRestoreConfirm = null },
            title = { Text("Restore this backup?") },
            text = {
                Text("This replaces all data currently on this device with \"${file.name}\". This can't be undone. The app will restart afterward.")
            },
            confirmButton = {
                TextButton(onClick = {
                    showRestoreConfirm = null
                    busy = BusyMode.RESTORING
                    scope.launch {
                        try {
                            val drive = DriveSyncManager(context, account!!)
                            val key = drive.getOrCreateSyncKey()
                            val (bytes, expectedChecksum) = drive.downloadBackupFile(file.id, key)
                            val actualChecksum = CryptoUtil.sha256(bytes)
                            if (expectedChecksum != null && expectedChecksum != actualChecksum) {
                                statusMsg = "Restore aborted: backup file failed integrity check"
                                busy = BusyMode.NONE
                                return@launch
                            }
                            BackupInstaller.installDatabaseFile(context, bytes)
                            BackupInstaller.restartApp(context)
                        } catch (e: Exception) {
                            statusMsg = "Restore failed: ${e.message}"
                            busy = BusyMode.NONE
                        }
                    }
                }) { Text("Restore") }
            },
            dismissButton = { TextButton(onClick = { showRestoreConfirm = null }) { Text("Cancel") } }
        )
    }

    if (showCloudFoundPrompt && account != null) {
        AlertDialog(
            onDismissRequest = { showCloudFoundPrompt = false },
            title = { Text("Cloud backup found") },
            text = { Text("This Google account already has attendance data backed up in the cloud. Restore it to this device now? This replaces any data currently on this device.") },
            confirmButton = {
                TextButton(onClick = {
                    showCloudFoundPrompt = false
                    busy = BusyMode.RESTORING
                    scope.launch {
                        try {
                            val drive = DriveSyncManager(context, account!!)
                            val key = drive.getOrCreateSyncKey()
                            val result = drive.downloadAutoBackup(key)
                            if (result != null) {
                                val (bytes, expectedChecksum) = result
                                val actualChecksum = CryptoUtil.sha256(bytes)
                                if (expectedChecksum != null && expectedChecksum != actualChecksum) {
                                    statusMsg = "Restore aborted: cloud backup failed integrity check"
                                    busy = BusyMode.NONE
                                    return@launch
                                }
                                BackupInstaller.installDatabaseFile(context, bytes)
                                BackupInstaller.restartApp(context)
                            }
                        } catch (e: Exception) {
                            statusMsg = "Restore failed: ${e.message}"
                            busy = BusyMode.NONE
                        }
                    }
                }) { Text("Restore") }
            },
            dismissButton = { TextButton(onClick = { showCloudFoundPrompt = false }) { Text("Not now") } }
        )
    }
}

@Composable
private fun SyncStatusBadge(status: SyncStatus) {
    val (color, label) = when (status) {
        SyncStatus.SYNCING -> Marigold to "Syncing…"
        SyncStatus.SYNCED -> Sage to "Synced"
        SyncStatus.FAILED -> Cinnabar to "Sync Failed"
        SyncStatus.IDLE -> Parchment.copy(alpha = 0.5f) to "Idle"
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(label, style = MaterialTheme.typography.labelMedium, color = color)
    }
}

private fun formatTime(millis: Long): String =
    SimpleDateFormat("MMM d, yyyy 'at' h:mm a", Locale.getDefault()).format(Date(millis))
