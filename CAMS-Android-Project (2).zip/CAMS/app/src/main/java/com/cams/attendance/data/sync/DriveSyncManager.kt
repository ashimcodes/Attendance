package com.cams.attendance.data.sync

import android.content.Context
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.http.ByteArrayContent
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.google.api.services.drive.model.File as DriveFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

data class DriveFolderInfo(val id: String, val name: String)
data class DriveBackupFileInfo(val id: String, val name: String, val modifiedTime: Long, val size: Long)

private const val KEY_FILE_NAME = "cams_sync.key"
private const val AUTO_BACKUP_FILE_NAME = "cams_auto_backup.enc"
private const val APP_DATA_SPACE = "appDataFolder"

class DriveSyncManager(private val context: Context, private val account: GoogleSignInAccount) {

    private val driveService: Drive by lazy { buildDriveService() }

    private fun buildDriveService(): Drive {
        val credential = GoogleAccountCredential.usingOAuth2(
            context, listOf(DriveScopes.DRIVE_FILE, DriveScopes.DRIVE_APPDATA)
        )
        credential.selectedAccount = account.account
        return Drive.Builder(NetHttpTransport(), GsonFactory.getDefaultInstance(), credential)
            .setApplicationName("CAMS Attendance")
            .build()
    }

    // --- Sync key exchange (see CryptoUtil for why this lives in appDataFolder, not Keystore) ---

    suspend fun getOrCreateSyncKey(): ByteArray = withContext(Dispatchers.IO) {
        val existing = findAppDataFile(KEY_FILE_NAME)
        if (existing != null) {
            val bytes = downloadFileBytes(existing.id)
            CryptoUtil.decodeKey(String(bytes, Charsets.UTF_8))
        } else {
            val newKey = CryptoUtil.generateKey()
            val encoded = CryptoUtil.encodeKey(newKey)
            val metadata = DriveFile().setName(KEY_FILE_NAME).setParents(listOf(APP_DATA_SPACE))
            val content = ByteArrayContent("text/plain", encoded.toByteArray(Charsets.UTF_8))
            driveService.files().create(metadata, content).setFields("id").execute()
            newKey
        }
    }

    private fun findAppDataFile(name: String): DriveFile? {
        val result = driveService.files().list()
            .setSpaces(APP_DATA_SPACE)
            .setQ("name = '$name' and trashed = false")
            .setFields("files(id, name, modifiedTime, size)")
            .execute()
        return result.files?.firstOrNull()
    }

    // --- Automatic hidden backup (appDataFolder) ---

    suspend fun uploadAutoBackup(encryptedBytes: ByteArray, checksum: String): Unit = withContext(Dispatchers.IO) {
        val existing = findAppDataFile(AUTO_BACKUP_FILE_NAME)
        val content = ByteArrayContent("application/octet-stream", encryptedBytes)
        if (existing != null) {
            val metadata = DriveFile().setAppProperties(mapOf("sha256" to checksum))
            driveService.files().update(existing.id, metadata, content).execute()
        } else {
            val metadata = DriveFile()
                .setName(AUTO_BACKUP_FILE_NAME)
                .setParents(listOf(APP_DATA_SPACE))
                .setAppProperties(mapOf("sha256" to checksum))
            driveService.files().create(metadata, content).setFields("id").execute()
        }
    }

    /** Returns (decrypted bytes, expected checksum) or null if no cloud backup exists yet. */
    suspend fun downloadAutoBackup(keyBytes: ByteArray): Pair<ByteArray, String?>? = withContext(Dispatchers.IO) {
        val file = driveService.files().list()
            .setSpaces(APP_DATA_SPACE)
            .setQ("name = '$AUTO_BACKUP_FILE_NAME' and trashed = false")
            .setFields("files(id, name, modifiedTime, appProperties)")
            .execute().files?.firstOrNull() ?: return@withContext null

        val encrypted = downloadFileBytes(file.id)
        val decrypted = CryptoUtil.decrypt(encrypted, keyBytes)
        decrypted to file.appProperties?.get("sha256")
    }

    suspend fun getAutoBackupModifiedTime(): Long? = withContext(Dispatchers.IO) {
        findAppDataFile(AUTO_BACKUP_FILE_NAME)?.modifiedTime?.value
    }

    // --- Manual visible backup/restore ---

    suspend fun listFolders(parentId: String = "root"): List<DriveFolderInfo> = withContext(Dispatchers.IO) {
        val result = driveService.files().list()
            .setSpaces("drive")
            .setQ("'$parentId' in parents and mimeType = 'application/vnd.google-apps.folder' and trashed = false")
            .setFields("files(id, name)")
            .setOrderBy("name")
            .execute()
        result.files?.map { DriveFolderInfo(it.id, it.name) } ?: emptyList()
    }

    suspend fun createFolder(name: String, parentId: String): DriveFolderInfo = withContext(Dispatchers.IO) {
        val metadata = DriveFile()
            .setName(name)
            .setMimeType("application/vnd.google-apps.folder")
            .setParents(listOf(parentId))
        val created = driveService.files().create(metadata).setFields("id, name").execute()
        DriveFolderInfo(created.id, created.name)
    }

    suspend fun listBackupFiles(folderId: String): List<DriveBackupFileInfo> = withContext(Dispatchers.IO) {
        val result = driveService.files().list()
            .setSpaces("drive")
            .setQ("'$folderId' in parents and trashed = false and name contains '.camsbackup'")
            .setFields("files(id, name, modifiedTime, size)")
            .setOrderBy("modifiedTime desc")
            .execute()
        result.files?.map {
            DriveBackupFileInfo(it.id, it.name, it.modifiedTime?.value ?: 0L, it.getSize() ?: 0L)
        } ?: emptyList()
    }

    suspend fun uploadManualBackup(folderId: String, fileName: String, encryptedBytes: ByteArray, checksum: String): String =
        withContext(Dispatchers.IO) {
            val metadata = DriveFile()
                .setName(fileName)
                .setParents(listOf(folderId))
                .setAppProperties(mapOf("sha256" to checksum))
            val content = ByteArrayContent("application/octet-stream", encryptedBytes)
            driveService.files().create(metadata, content).setFields("id").execute().id
        }

    suspend fun downloadBackupFile(fileId: String, keyBytes: ByteArray): Pair<ByteArray, String?> = withContext(Dispatchers.IO) {
        val meta = driveService.files().get(fileId).setFields("appProperties").execute()
        val encrypted = downloadFileBytes(fileId)
        val decrypted = CryptoUtil.decrypt(encrypted, keyBytes)
        decrypted to meta.appProperties?.get("sha256")
    }

    private fun downloadFileBytes(fileId: String): ByteArray {
        val out = ByteArrayOutputStream()
        driveService.files().get(fileId).executeMediaAndDownloadTo(out)
        return out.toByteArray()
    }
}
