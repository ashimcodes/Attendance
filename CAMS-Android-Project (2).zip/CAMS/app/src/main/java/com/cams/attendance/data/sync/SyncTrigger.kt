package com.cams.attendance.data.sync

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

/**
 * Called after every data mutation (student/teacher/class/attendance CRUD).
 * Debounces rapid successive writes into a single sync a few seconds later,
 * and only actually runs once a network connection is available — this is
 * what gives us "offline support with automatic sync when reconnected" for
 * free via WorkManager's constraint system, rather than a custom queue.
 */
object SyncTrigger {
    private const val UNIQUE_WORK_NAME = "cams_auto_sync"

    fun scheduleSync(context: Context) {
        SyncPrefs.touchLocalChange(context)
        if (!SyncPrefs.isAutoSyncEnabled(context)) return

        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val request = OneTimeWorkRequestBuilder<SyncWorker>()
            .setConstraints(constraints)
            .setInitialDelay(6, TimeUnit.SECONDS) // debounce: coalesce bursts of edits into one upload
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            UNIQUE_WORK_NAME,
            ExistingWorkPolicy.REPLACE,
            request
        )
    }

    /** Manual "Sync Now" — runs immediately, no debounce delay. */
    fun syncNow(context: Context) {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        val request = OneTimeWorkRequestBuilder<SyncWorker>()
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            UNIQUE_WORK_NAME,
            ExistingWorkPolicy.REPLACE,
            request
        )
    }
}
