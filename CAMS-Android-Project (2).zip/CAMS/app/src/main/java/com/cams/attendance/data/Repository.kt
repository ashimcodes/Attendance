package com.cams.attendance.data

import android.content.Context
import com.cams.attendance.data.entity.*
import com.cams.attendance.data.sync.SyncTrigger
import org.mindrot.jbcrypt.BCrypt

data class StudentAttendanceSummary(
    val overallPercent: Int,
    val lastDate: String?,
    val lastStatus: AttendanceStatus?
)

/**
 * [context] is used only to schedule a debounced background cloud sync
 * (via [SyncTrigger]) after every mutating call — the whole-database-file
 * approach means any write anywhere should eventually get backed up.
 */
class Repository(private val db: AppDatabase, private val context: Context) {

    private fun touched() = SyncTrigger.scheduleSync(context)

    // --- Auth ---
    suspend fun login(username: String, password: String): User? {
        val user = db.userDao().findByUsername(username) ?: return null
        return if (BCrypt.checkpw(password, user.passwordHash)) user else null
    }

    /** Used by fingerprint sign-in: device biometric already proved identity, so no password check here. */
    suspend fun findByUsername(username: String): User? = db.userDao().findByUsername(username)

    suspend fun createUser(username: String, password: String, fullName: String, role: Role, teacherId: Long? = null) {
        val hash = BCrypt.hashpw(password, BCrypt.gensalt())
        db.userDao().upsert(User(username = username, passwordHash = hash, fullName = fullName, role = role, teacherId = teacherId))
        touched()
    }

    fun users() = db.userDao().getAll()
    suspend fun deleteUser(u: User) { db.userDao().delete(u); touched() }

    // --- Departments ---
    fun departments() = db.departmentDao().getAll()
    suspend fun saveDepartment(d: Department): Long = db.departmentDao().upsert(d).also { touched() }
    suspend fun deleteDepartment(d: Department) { db.departmentDao().delete(d); touched() }

    // --- Classes ---
    fun classes() = db.classDao().getAll()
    suspend fun getClass(id: Long) = db.classDao().getById(id)
    suspend fun saveClass(c: ClassEntity): Long = db.classDao().upsert(c).also { touched() }
    suspend fun deleteClass(c: ClassEntity) { db.classDao().delete(c); touched() }

    // --- Subjects ---
    fun subjects() = db.subjectDao().getAll()
    suspend fun saveSubject(s: Subject): Long = db.subjectDao().upsert(s).also { touched() }
    suspend fun deleteSubject(s: Subject) { db.subjectDao().delete(s); touched() }

    // --- Teachers ---
    fun teachers() = db.teacherDao().getAll()
    suspend fun saveTeacher(t: Teacher): Long = db.teacherDao().upsert(t).also { touched() }
    suspend fun deleteTeacher(t: Teacher) { db.teacherDao().delete(t); touched() }

    // --- Students ---
    fun students() = db.studentDao().getAll()
    fun studentsByClass(classId: Long) = db.studentDao().getByClass(classId)
    fun searchStudents(q: String) = db.studentDao().search(q)
    suspend fun saveStudent(s: Student): Long = db.studentDao().upsert(s).also { touched() }
    suspend fun deleteStudent(s: Student) { db.studentDao().delete(s); touched() }

    // --- Attendance ---
    fun attendanceForClassDate(classId: Long, date: String) = db.attendanceDao().getForClassAndDate(classId, date)

    suspend fun markAttendance(studentId: Long, classId: Long, date: String, status: AttendanceStatus, markedBy: Long?) {
        val existing = db.attendanceDao().findOne(studentId, classId, date)
        db.attendanceDao().upsert(
            Attendance(
                id = existing?.id ?: 0,
                studentId = studentId,
                classId = classId,
                date = date,
                status = status,
                markedBy = markedBy
            )
        )
        touched()
    }

    suspend fun unmarkAttendance(studentId: Long, classId: Long, date: String) {
        db.attendanceDao().deleteOne(studentId, classId, date)
        touched()
    }

    suspend fun reportForClass(classId: Long, from: String, to: String) =
        db.attendanceDao().getForClassAndRange(classId, from, to)

    suspend fun reportForStudent(studentId: Long, from: String, to: String) =
        db.attendanceDao().getForStudentAndRange(studentId, from, to)

    suspend fun studentSummary(studentId: Long): StudentAttendanceSummary {
        val last = db.attendanceDao().getLastForStudent(studentId)
        val present = db.attendanceDao().countPresentForStudent(studentId)
        val total = db.attendanceDao().countTotalForStudent(studentId)
        val pct = if (total > 0) (present * 100 / total) else 0
        return StudentAttendanceSummary(overallPercent = pct, lastDate = last?.date, lastStatus = last?.status)
    }

    // --- Audit ---
    fun auditLogs() = db.auditLogDao().getRecent()
    suspend fun logAction(userId: Long?, action: String, entity: String? = null, entityId: Long? = null, details: String? = null) {
        db.auditLogDao().insert(AuditLog(userId = userId, action = action, entity = entity, entityId = entityId, details = details))
        touched()
    }
}
