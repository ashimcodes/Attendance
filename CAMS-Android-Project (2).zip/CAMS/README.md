# CAMS Attendance — Android App

A native Android rewrite of the CAMS (College Attendance Management System)
PHP/MySQL app, as a standalone Kotlin + Jetpack Compose app with a local
SQLite (Room) database. **No PHP server or MySQL required** — everything
runs on-device.

## What's included
- Login with roles (Admin / Teacher), default seeded login: `admin` / `admin123`
- Students, Teachers, Classes management (add / edit / delete)
- Mark daily attendance per class (Present / Absent / Late) — classic table mode
- **Swipe Attendance** — Tinder-style one-at-a-time card interface:
  - Swipe up = Present, down = Absent, left = Skip, right = View details
  - Mouse drag works the same way on desktop/tablet with a mouse
  - Card rotates while dragging, springs back if released before threshold,
    flies off-screen on a completed swipe, glows green/red based on drag direction
  - Tap the card (or press Space, if a hardware keyboard is attached) to flip it —
    front shows photo/name/roll/class info, back shows parent name, parent phone,
    overall attendance %, last marked date, and remarks
  - Floating progress panel: current student #, total, present, absent, remaining,
    running attendance %, with a live progress bar
  - Undo button reverts the last mark; skipped students are automatically
    revisited in a second pass at the end
  - Keyboard shortcuts on devices with a hardware keyboard: ↑ Present, ↓ Absent,
    → Skip, ← Previous
  - Animated completion screen with totals, Review/Edit buttons, and CSV/PDF export
  - Not included in this pass (flagged as "bonus" items, out of scope for now):
    facial recognition, offline sync, QR-code attendance, voice commands
- Reports with per-student attendance % and CSV & PDF export (saved to
  `Downloads/CAMS/`)
- Admin: user management, audit log, one-tap database backup export
- **Google account sign-in & cloud backup** (see `SETUP-GOOGLE-DRIVE.md` — requires a
  one-time Google Cloud Console setup you do yourself, same idea as the Android
  keystore SHA-1 requirement):
  - Sign in with Google from the new **Settings** screen
  - Automatic encrypted background sync to your Drive whenever data changes
    (debounced, offline-safe — queues until network is back via WorkManager)
  - Manual **Online Backup** / **Restore Backup** to a folder you choose in your
    Drive, via a simple in-app folder browser
  - Sync status (Syncing / Synced / Sync Failed), last-sync time, manual "Sync Now",
    an auto-sync on/off toggle, and a backup-overdue reminder banner
  - AES-256-GCM encryption for every backup; the key itself lives in your Drive's
    private `appDataFolder` (not on-device Keystore) specifically so a backup made
    on one device can be restored on another, or after a reinstall
  - Checksum integrity verification before any restore is applied
  - Prompts to restore automatically after signing in if a cloud backup already exists
  - **Important architecture note**: this is whole-database-file sync with
    last-write-wins, not row-level real-time merging — editing the same record on two
    devices at the same moment means one device's version wins, not both merged.
    True real-time multi-device sync would require replacing Room/SQLite with a
    sync-aware backend (e.g. Firestore), which is a much larger rewrite than this pass.

## Option A: Build the APK on GitHub (no install needed on your computer)

This project includes a ready-made GitHub Actions workflow
(`.github/workflows/build-apk.yml`) that compiles the APK on GitHub's
servers — you don't need Android Studio or any SDK installed locally.

1. Create a free GitHub account at https://github.com/join if you don't have one.
2. Create a new **empty** repository (e.g. `cams-attendance`) at
   https://github.com/new — don't add a README/gitignore when creating it.
3. Upload this entire `CAMS` folder's contents to that repo. Easiest way:
   on the repo page, click **Add file → Upload files**, then drag in
   everything from inside this `CAMS` folder (keep the folder structure).
4. Once uploaded, GitHub Actions will start automatically (or go to the
   **Actions** tab → **Build APK** workflow → **Run workflow** if it
   doesn't start on its own).
5. Wait for the green checkmark (a few minutes), then click into that run →
   scroll to **Artifacts** → download `cams-attendance-debug-apk`. Unzip it
   and you'll have `app-debug.apk` — the real installable file.
6. Transfer that `.apk` to your Android phone (email it to yourself, Google
   Drive, USB, etc.), open it, and allow "install from unknown sources" if
   prompted.

## Option B: Build the APK with Android Studio

You need **Android Studio** (free, from https://developer.android.com/studio).
This project could not be compiled into an APK in the sandbox that generated
it because that sandbox has no internet access to download the Android
SDK/Gradle — Android Studio will fetch what it needs automatically.

1. Install Android Studio (Hedgehog / 2023.1+ or newer).
2. Open Android Studio → **Open** → select this `CAMS` folder.
3. Let it sync (first sync downloads Gradle + SDK components — needs internet,
   takes a few minutes).
4. Connect an Android phone (USB debugging on) or use an emulator.
5. Click **Run ▶**. That's it — installs and launches on the device.

To get a shareable `.apk` file instead of running from Studio:
**Build → Build App Bundle(s) / APK(s) → Build APK(s)**, then
**locate** the generated file (Studio shows a notification with a link),
typically at `app/build/outputs/apk/debug/app-debug.apk`.

## Project structure
```
app/src/main/java/com/cams/attendance/
  data/entity/    Room entities (Student, Teacher, ClassEntity, Attendance, User, ...)
  data/dao/       Room DAOs
  data/           AppDatabase, Repository (business logic), Converters
  ui/screens/     Compose screens (Login, Dashboard, Students, Teachers,
                  Classes, Attendance, Reports, Admin)
  ui/theme/       Colors / Material 3 theme
  util/           CSV and PDF exporters
  MainActivity.kt Navigation host, app entry point
```

## Notes / next steps
- The database is local to the device (Room/SQLite) — there's currently no
  sync between multiple phones. If you need multi-device sync later, the
  `Repository` class is the seam where a REST API backend could be plugged
  in with minimal UI changes.
- Passwords are hashed with bcrypt (jBCrypt), matching the original PHP app's
  approach.
- Subject-level attendance and teacher-class assignment tables exist in the
  original PHP schema but aren't yet wired into the UI — the `Subject` entity/DAO
  are scaffolded and ready to extend.
