# Google Sign-In & Drive Backup — One-Time Setup

The app's code for Google Sign-In and Drive backup/sync is already written and
included in this project. But **none of it can work until you complete a
one-time setup in Google's own consoles** — this is a hard requirement from
Google, not something that can be skipped or automated from outside a browser
session you're logged into.

This takes about 10 minutes and you only do it once.

## Why Google Sign-In (not Firebase Authentication)

You'll notice the app uses classic Google Sign-In (`play-services-auth`)
rather than Firebase Authentication. This is intentional: the app doesn't use
any Firebase backend (no Firestore, no Realtime Database) — data goes
straight from your device to your own Google Drive. Firebase Auth would mean
setting up an entire separate Firebase project for no functional benefit,
since what the app actually needs is a Google account + a Drive-scoped OAuth
token, which plain Google Sign-In already provides directly. One less system
to configure.

## Step 1 — Get your app's SHA-1 fingerprint

Google needs to know which exact app build is allowed to sign in. That's tied
to your app's package name (`com.cams.attendance`) **and** the SHA-1
fingerprint of the certificate it's signed with.

Since this project builds via the included GitHub Actions workflow, the
easiest way to get it:
1. Push this project to GitHub (as you've already been doing) and let the
   **Build APK** workflow run.
2. Open the finished workflow run → find the step called **"Print debug
   keystore SHA-1"** → copy the fingerprint shown there (a string like
   `A1:B2:C3:...`).

This is your **debug** SHA-1 — it's fine for personal use and testing. If you
later publish a release build signed with a different key, you'll need to add
that build's SHA-1 too (same process, just a second entry in Step 3 below).

## Step 2 — Create a Google Cloud project

1. Go to https://console.cloud.google.com/
2. Click the project dropdown (top left) → **New Project**
3. Give it any name (e.g. "CAMS Attendance") → **Create**
4. Make sure this new project is selected in the dropdown before continuing

## Step 3 — Enable the Drive API

1. In the left sidebar: **APIs & Services → Library**
2. Search for **Google Drive API** → click it → **Enable**

## Step 4 — Configure the OAuth consent screen

1. **APIs & Services → OAuth consent screen**
2. User type: **External** → **Create**
3. Fill in App name, your email (as both support email and developer contact) → **Save and Continue**
4. On the **Scopes** step, click **Add or Remove Scopes** and add:
   - `.../auth/drive.file`
   - `.../auth/drive.appdata`
   Save and continue.
5. On the **Test users** step, click **Add Users** and add the Google
   account(s) you'll actually sign in with in the app. While the app is in
   "Testing" mode, **only accounts listed here can sign in** — this is normal
   and fine for personal use; it avoids Google's full app-review process,
   which is only needed if you plan to publish this publicly to strangers.
6. Save and finish.

## Step 5 — Create the OAuth Client ID

1. **APIs & Services → Credentials → Create Credentials → OAuth client ID**
2. Application type: **Android**
3. Package name: `com.cams.attendance`
4. SHA-1 certificate fingerprint: paste the value from Step 1
5. **Create**

That's it — no client ID or secret needs to be pasted into the app's code.
Google Sign-In on Android matches sign-in requests to this OAuth client
automatically using the package name + SHA-1, entirely server-side.

## Step 6 — Try it

Build and install the APK as usual. On the Settings screen, tap **Sign in
with Google**, choose the account you added as a test user in Step 4. You
should see it succeed and the Cloud Sync card appear.

## Troubleshooting

- **"Sign-in was cancelled or failed" immediately**: almost always a
  mismatched SHA-1 or package name in Step 5, or your account isn't listed as
  a test user in Step 4.
- **Sign-in succeeds but Drive calls fail**: double check the Drive API is
  actually enabled (Step 3) — it can take a few minutes to propagate after
  enabling.
- **"App is blocked" warning during sign-in**: expected while in Testing mode
  for any account *not* added as a test user. Add it in Step 4.
