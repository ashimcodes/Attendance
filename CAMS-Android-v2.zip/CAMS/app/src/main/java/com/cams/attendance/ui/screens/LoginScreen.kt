package com.cams.attendance.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.cams.attendance.data.Repository
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(repo: Repository, onLoginSuccess: (com.cams.attendance.data.entity.User) -> Unit) {
    var username by remember { mutableStateOf("admin") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            Modifier.padding(32.dp).widthIn(max = 400.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Filled.Lock, contentDescription = null, modifier = Modifier.size(48.dp))
            Spacer(Modifier.height(12.dp))
            Text("CAMS Attendance", style = MaterialTheme.typography.headlineSmall)
            Text("College Attendance Management System", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(24.dp))

            OutlinedTextField(
                value = username, onValueChange = { username = it },
                label = { Text("Username") }, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = password, onValueChange = { password = it },
                label = { Text("Password") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            error?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    scope.launch {
                        val user = repo.login(username.trim(), password)
                        if (user != null) {
                            repo.logAction(user.id, "login", "user", user.id)
                            onLoginSuccess(user)
                        } else {
                            error = "Invalid username or password"
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Log In") }

            Spacer(Modifier.height(12.dp))
            Text("Default admin login: admin / admin123", style = MaterialTheme.typography.labelSmall)
        }
    }
}
