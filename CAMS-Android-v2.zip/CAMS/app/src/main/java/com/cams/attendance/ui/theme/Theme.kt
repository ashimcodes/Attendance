package com.cams.attendance.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Primary = Color(0xFF2F6FED)
val PrimaryDark = Color(0xFF184BB0)
val Surface = Color(0xFFF7F9FC)

private val LightColors = lightColorScheme(
    primary = Primary,
    secondary = PrimaryDark,
    background = Surface
)

private val DarkColors = darkColorScheme(
    primary = Primary,
    secondary = PrimaryDark
)

@Composable
fun CAMSTheme(content: @Composable () -> Unit) {
    val colors = if (isSystemInDarkTheme()) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, content = content)
}
