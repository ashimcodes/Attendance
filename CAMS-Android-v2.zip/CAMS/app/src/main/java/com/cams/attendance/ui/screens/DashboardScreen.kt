package com.cams.attendance.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cams.attendance.data.Repository
import com.cams.attendance.data.entity.Role
import com.cams.attendance.data.entity.User
import com.cams.attendance.ui.Routes

data class DashTile(val label: String, val route: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
fun DashboardScreen(repo: Repository, user: User, onNavigate: (String) -> Unit) {
    val students by repo.students().collectAsState(initial = emptyList())
    val teachers by repo.teachers().collectAsState(initial = emptyList())
    val classes by repo.classes().collectAsState(initial = emptyList())

    val tiles = buildList {
        add(DashTile("Students", Routes.STUDENTS, Icons.Filled.Person))
        add(DashTile("Teachers", Routes.TEACHERS, Icons.Filled.Face))
        add(DashTile("Classes", Routes.CLASSES, Icons.Filled.List))
        add(DashTile("Mark Attendance", Routes.ATTENDANCE, Icons.Filled.CheckCircle))
        add(DashTile("Swipe Attendance", Routes.SWIPE_FILTERS, Icons.Filled.TouchApp))
        add(DashTile("Reports", Routes.REPORTS, Icons.Filled.Assessment))
        if (user.role == Role.ADMIN) add(DashTile("Admin", Routes.ADMIN, Icons.Filled.Settings))
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Welcome, ${user.fullName}", style = MaterialTheme.typography.headlineSmall)
        Text(if (user.role == Role.ADMIN) "Administrator" else "Teacher", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(16.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            StatCard("Students", students.size.toString(), Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            StatCard("Teachers", teachers.size.toString(), Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            StatCard("Classes", classes.size.toString(), Modifier.weight(1f))
        }

        Spacer(Modifier.height(20.dp))
        Text("Quick Actions", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))

        LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(tiles) { tile ->
                ElevatedCard(onClick = { onNavigate(tile.route) }, modifier = Modifier.fillMaxWidth().height(90.dp)) {
                    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(tile.icon, contentDescription = tile.label)
                        Spacer(Modifier.height(6.dp))
                        Text(tile.label, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    ElevatedCard(modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(value, style = MaterialTheme.typography.headlineMedium)
            Text(label, style = MaterialTheme.typography.bodySmall)
        }
    }
}
