# CAMS Attendance — Android App

A native Android rewrite of the CAMS (College Attendance Management System)
PHP/MySQL app, as a standalone Kotlin + Jetpack Compose app with a local
SQLite (Room) database. **No PHP server or MySQL required** — everything
runs on-device.

## What's included
- Login with roles (Admin / Teacher), default seeded login: `admin` / `admin123`
- Students, Teachers, Classes management (add / edit / delete)
- Mark daily attendance per class (Present / Absent / Late)
- Reports with per-student attendance % and **CSV & PDF export** (saved to
  `Downloads/CAMS/`)
- Admin: user management, audit log, one-tap database backup export

## Option A: Build the APK on GitHub (no install needed on your computer)

This project includes a ready-made GitHub Actions workflow
(`.github/workflows/build-apk.yml`) that compiles the APK on GitHub's
servers — you don't need Android Studio or any SDK installed locally.

1. Create a free GitHub account at https://github.com/join if you don't have one.
2. Create a new **empty** repository (e.g. `cams-attendance`) at
   https://github.com/new — don't add a README/gitignore when creating it.
3. Upload this entire `CAMS` folder's contents to that repo. Easiest way:
   on the repo page, click **Add file → Upload files**, then drag in
   everything from inside this `CAMS` folder (keep the folder structure).
4. Once uploaded, GitHub Actions will start automatically (or go to the
   **Actions** tab → **Build APK** workflow → **Run workflow** if it
   doesn't start on its own).
5. Wait for the green checkmark (a few minutes), then click into that run →
   scroll to **Artifacts** → download `cams-attendance-debug-apk`. Unzip it
   and you'll have `app-debug.apk` — the real installable file.
6. Transfer that `.apk` to your Android phone (email it to yourself, Google
   Drive, USB, etc.), open it, and allow "install from unknown sources" if
   prompted.

## Option B: Build the APK with Android Studio

You need **Android Studio** (free, from https://developer.android.com/studio).
This project could not be compiled into an APK in the sandbox that generated
it because that sandbox has no internet access to download the Android
SDK/Gradle — Android Studio will fetch what it needs automatically.

1. Install Android Studio (Hedgehog / 2023.1+ or newer).
2. Open Android Studio → **Open** → select this `CAMS` folder.
3. Let it sync (first sync downloads Gradle + SDK components — needs internet,
   takes a few minutes).
4. Connect an Android phone (USB debugging on) or use an emulator.
5. Click **Run ▶**. That's it — installs and launches on the device.

To get a shareable `.apk` file instead of running from Studio:
**Build → Build App Bundle(s) / APK(s) → Build APK(s)**, then
**locate** the generated file (Studio shows a notification with a link),
typically at `app/build/outputs/apk/debug/app-debug.apk`.

## Project structure
```
app/src/main/java/com/cams/attendance/
  data/entity/    Room entities (Student, Teacher, ClassEntity, Attendance, User, ...)
  data/dao/       Room DAOs
  data/           AppDatabase, Repository (business logic), Converters
  ui/screens/     Compose screens (Login, Dashboard, Students, Teachers,
                  Classes, Attendance, Reports, Admin)
  ui/theme/       Colors / Material 3 theme
  util/           CSV and PDF exporters
  MainActivity.kt Navigation host, app entry point
```

## Notes / next steps
- The database is local to the device (Room/SQLite) — there's currently no
  sync between multiple phones. If you need multi-device sync later, the
  `Repository` class is the seam where a REST API backend could be plugged
  in with minimal UI changes.
- Passwords are hashed with bcrypt (jBCrypt), matching the original PHP app's
  approach.
- Subject-level attendance and teacher-class assignment tables exist in the
  original PHP schema but aren't yet wired into the UI — the `Subject` entity/DAO
  are scaffolded and ready to extend.
