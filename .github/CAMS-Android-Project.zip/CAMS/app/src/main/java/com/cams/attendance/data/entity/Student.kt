package com.cams.attendance.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "students")
data class Student(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentCode: String,
    val fullName: String,
    val rollNumber: String,
    val departmentId: Long,
    val classId: Long,
    val email: String? = null,
    val phone: String? = null
)
