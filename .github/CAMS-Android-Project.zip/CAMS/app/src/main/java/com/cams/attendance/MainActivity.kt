package com.cams.attendance

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.cams.attendance.data.AppDatabase
import com.cams.attendance.data.Repository
import com.cams.attendance.data.entity.User
import com.cams.attendance.ui.Routes
import com.cams.attendance.ui.screens.*
import com.cams.attendance.ui.theme.CAMSTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.getInstance(applicationContext)
        val repo = Repository(db)

        setContent {
            CAMSTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    CamsApp(repo)
                }
            }
        }
    }
}

@Composable
fun CamsApp(repo: Repository) {
    val navController = rememberNavController()
    var currentUser by remember { mutableStateOf<User?>(null) }

    if (currentUser == null) {
        LoginScreen(repo) { user -> currentUser = user }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("CAMS Attendance") },
                navigationIcon = {
                    if (navController.previousBackStackEntry != null) {
                        IconButton(onClick = { navController.popBackStack() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                actions = {
                    IconButton(onClick = {
                        currentUser = null
                        navController.navigate(Routes.DASHBOARD) {
                            popUpTo(0)
                        }
                    }) {
                        Icon(Icons.Filled.Logout, contentDescription = "Log out")
                    }
                }
            )
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            NavHost(navController = navController, startDestination = Routes.DASHBOARD) {
                composable(Routes.DASHBOARD) {
                    val user = currentUser
                    if (user != null) {
                        DashboardScreen(repo, user) { route -> navController.navigate(route) }
                    }
                }
                composable(Routes.STUDENTS) { StudentsScreen(repo) }
                composable(Routes.TEACHERS) { TeachersScreen(repo) }
                composable(Routes.CLASSES) { ClassesScreen(repo) }
                composable(Routes.ATTENDANCE) {
                    val user = currentUser
                    if (user != null) AttendanceScreen(repo, user)
                }
                composable(Routes.REPORTS) { ReportsScreen(repo) }
                composable(Routes.ADMIN) { AdminScreen(repo) }
            }
        }
    }
}
