package com.cams.attendance.ui

object Routes {
    const val LOGIN = "login"
    const val DASHBOARD = "dashboard"
    const val STUDENTS = "students"
    const val TEACHERS = "teachers"
    const val CLASSES = "classes"
    const val ATTENDANCE = "attendance"
    const val REPORTS = "reports"
    const val ADMIN = "admin"
}
