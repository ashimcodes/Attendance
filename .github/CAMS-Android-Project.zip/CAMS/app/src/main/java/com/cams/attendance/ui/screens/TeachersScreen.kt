package com.cams.attendance.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cams.attendance.data.Repository
import com.cams.attendance.data.entity.Teacher
import kotlinx.coroutines.launch

@Composable
fun TeachersScreen(repo: Repository) {
    val teachers by repo.teachers().collectAsState(initial = emptyList())
    var editing by remember { mutableStateOf<Teacher?>(null) }
    var showForm by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { editing = null; showForm = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Add teacher")
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            Text("Teachers (${teachers.size})", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(teachers, key = { it.id }) { t ->
                    ElevatedCard {
                        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(t.fullName, style = MaterialTheme.typography.titleMedium)
                                Text(t.employeeCode ?: "", style = MaterialTheme.typography.bodySmall)
                                Text(listOfNotNull(t.email, t.phone).joinToString(" · "), style = MaterialTheme.typography.bodySmall)
                            }
                            Row {
                                IconButton(onClick = { editing = t; showForm = true }) {
                                    Icon(Icons.Filled.Edit, contentDescription = "Edit")
                                }
                                IconButton(onClick = { scope.launch { repo.deleteTeacher(t) } }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Delete")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showForm) {
        TeacherFormDialog(
            teacher = editing,
            onDismiss = { showForm = false },
            onSave = { t -> scope.launch { repo.saveTeacher(t) }; showForm = false }
        )
    }
}

@Composable
private fun TeacherFormDialog(teacher: Teacher?, onDismiss: () -> Unit, onSave: (Teacher) -> Unit) {
    var fullName by remember { mutableStateOf(teacher?.fullName ?: "") }
    var email by remember { mutableStateOf(teacher?.email ?: "") }
    var phone by remember { mutableStateOf(teacher?.phone ?: "") }
    var employeeCode by remember { mutableStateOf(teacher?.employeeCode ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (teacher == null) "Add Teacher" else "Edit Teacher") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(fullName, { fullName = it }, label = { Text("Full name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(employeeCode, { employeeCode = it }, label = { Text("Employee code") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(email, { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(phone, { phone = it }, label = { Text("Phone") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    Teacher(
                        id = teacher?.id ?: 0,
                        fullName = fullName,
                        email = email.ifBlank { null },
                        phone = phone.ifBlank { null },
                        employeeCode = employeeCode.ifBlank { null }
                    )
                )
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
