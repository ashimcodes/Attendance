package com.cams.attendance.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.cams.attendance.data.dao.*
import com.cams.attendance.data.entity.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.mindrot.jbcrypt.BCrypt

@Database(
    entities = [
        Department::class, ClassEntity::class, Subject::class, Teacher::class,
        Student::class, Attendance::class, User::class, AuditLog::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun departmentDao(): DepartmentDao
    abstract fun classDao(): ClassDao
    abstract fun subjectDao(): SubjectDao
    abstract fun teacherDao(): TeacherDao
    abstract fun studentDao(): StudentDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun userDao(): UserDao
    abstract fun auditLogDao(): AuditLogDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "cams.db"
                ).addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Seed default admin (admin / admin123) and reference data on first run
                        CoroutineScope(Dispatchers.IO).launch {
                            seed(getInstance(context))
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun seed(db: AppDatabase) {
            if (db.userDao().count() > 0) return

            val hash = BCrypt.hashpw("admin123", BCrypt.gensalt())
            db.userDao().upsert(
                User(username = "admin", passwordHash = hash, fullName = "Administrator", role = Role.ADMIN)
            )

            val deptId = db.departmentDao().upsert(Department(name = "Computer Science", code = "CSE"))
            db.departmentDao().upsert(Department(name = "Electronics & Communication", code = "ECE"))
            db.departmentDao().upsert(Department(name = "Mechanical Engineering", code = "ME"))
            db.departmentDao().upsert(Department(name = "Civil Engineering", code = "CE"))

            db.classDao().upsert(
                ClassEntity(name = "CSE Year 1 - Sem 1 - A", departmentId = deptId, semester = "Semester 1", section = "A", year = 1)
            )
        }
    }
}
