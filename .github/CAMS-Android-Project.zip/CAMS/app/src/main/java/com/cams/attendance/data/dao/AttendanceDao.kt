package com.cams.attendance.data.dao

import androidx.room.*
import com.cams.attendance.data.entity.Attendance
import kotlinx.coroutines.flow.Flow

@Dao
interface AttendanceDao {
    @Query("SELECT * FROM attendance WHERE classId = :classId AND date = :date")
    fun getForClassAndDate(classId: Long, date: String): Flow<List<Attendance>>

    @Query("""
        SELECT * FROM attendance
        WHERE classId = :classId AND date BETWEEN :from AND :to
        ORDER BY date
    """)
    suspend fun getForClassAndRange(classId: Long, from: String, to: String): List<Attendance>

    @Query("""
        SELECT * FROM attendance
        WHERE studentId = :studentId AND date BETWEEN :from AND :to
        ORDER BY date
    """)
    suspend fun getForStudentAndRange(studentId: Long, from: String, to: String): List<Attendance>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(a: Attendance): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(list: List<Attendance>)

    @Query("SELECT * FROM attendance WHERE studentId = :studentId AND classId = :classId AND date = :date LIMIT 1")
    suspend fun findOne(studentId: Long, classId: Long, date: String): Attendance?
}
