package com.cams.attendance.data

import com.cams.attendance.data.entity.*
import org.mindrot.jbcrypt.BCrypt

class Repository(private val db: AppDatabase) {

    // --- Auth ---
    suspend fun login(username: String, password: String): User? {
        val user = db.userDao().findByUsername(username) ?: return null
        return if (BCrypt.checkpw(password, user.passwordHash)) user else null
    }

    suspend fun createUser(username: String, password: String, fullName: String, role: Role, teacherId: Long? = null) {
        val hash = BCrypt.hashpw(password, BCrypt.gensalt())
        db.userDao().upsert(User(username = username, passwordHash = hash, fullName = fullName, role = role, teacherId = teacherId))
    }

    fun users() = db.userDao().getAll()
    suspend fun deleteUser(u: User) = db.userDao().delete(u)

    // --- Departments ---
    fun departments() = db.departmentDao().getAll()
    suspend fun saveDepartment(d: Department) = db.departmentDao().upsert(d)
    suspend fun deleteDepartment(d: Department) = db.departmentDao().delete(d)

    // --- Classes ---
    fun classes() = db.classDao().getAll()
    suspend fun getClass(id: Long) = db.classDao().getById(id)
    suspend fun saveClass(c: ClassEntity) = db.classDao().upsert(c)
    suspend fun deleteClass(c: ClassEntity) = db.classDao().delete(c)

    // --- Subjects ---
    fun subjects() = db.subjectDao().getAll()
    suspend fun saveSubject(s: Subject) = db.subjectDao().upsert(s)
    suspend fun deleteSubject(s: Subject) = db.subjectDao().delete(s)

    // --- Teachers ---
    fun teachers() = db.teacherDao().getAll()
    suspend fun saveTeacher(t: Teacher) = db.teacherDao().upsert(t)
    suspend fun deleteTeacher(t: Teacher) = db.teacherDao().delete(t)

    // --- Students ---
    fun students() = db.studentDao().getAll()
    fun studentsByClass(classId: Long) = db.studentDao().getByClass(classId)
    fun searchStudents(q: String) = db.studentDao().search(q)
    suspend fun saveStudent(s: Student) = db.studentDao().upsert(s)
    suspend fun deleteStudent(s: Student) = db.studentDao().delete(s)

    // --- Attendance ---
    fun attendanceForClassDate(classId: Long, date: String) = db.attendanceDao().getForClassAndDate(classId, date)

    suspend fun markAttendance(studentId: Long, classId: Long, date: String, status: AttendanceStatus, markedBy: Long?) {
        val existing = db.attendanceDao().findOne(studentId, classId, date)
        db.attendanceDao().upsert(
            Attendance(
                id = existing?.id ?: 0,
                studentId = studentId,
                classId = classId,
                date = date,
                status = status,
                markedBy = markedBy
            )
        )
    }

    suspend fun reportForClass(classId: Long, from: String, to: String) =
        db.attendanceDao().getForClassAndRange(classId, from, to)

    suspend fun reportForStudent(studentId: Long, from: String, to: String) =
        db.attendanceDao().getForStudentAndRange(studentId, from, to)

    // --- Audit ---
    fun auditLogs() = db.auditLogDao().getRecent()
    suspend fun logAction(userId: Long?, action: String, entity: String? = null, entityId: Long? = null, details: String? = null) {
        db.auditLogDao().insert(AuditLog(userId = userId, action = action, entity = entity, entityId = entityId, details = details))
    }
}
