package com.cams.attendance.util

import android.content.Context

object Prefs {
    private const val FILE = "cams_prefs"
    private const val KEY_LAST_USERNAME = "last_username"
    private const val KEY_BIOMETRIC_ENABLED = "biometric_enabled"

    private fun prefs(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun setLastUsername(context: Context, username: String) {
        prefs(context).edit().putString(KEY_LAST_USERNAME, username).apply()
    }

    fun getLastUsername(context: Context): String? = prefs(context).getString(KEY_LAST_USERNAME, null)

    fun setBiometricEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_BIOMETRIC_ENABLED, enabled).apply()
    }

    fun isBiometricEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_BIOMETRIC_ENABLED, false)
}
