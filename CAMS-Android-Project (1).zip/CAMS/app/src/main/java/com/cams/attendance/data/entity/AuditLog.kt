package com.cams.attendance.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "audit_logs")
data class AuditLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long?,
    val action: String,
    val entity: String?,
    val entityId: Long?,
    val details: String?,
    val createdAt: Long = System.currentTimeMillis()
)
