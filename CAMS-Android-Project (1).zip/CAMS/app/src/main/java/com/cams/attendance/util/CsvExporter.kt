package com.cams.attendance.util

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore

object CsvExporter {
    /** Writes CSV text to Downloads/CAMS/<fileName> and returns a user-facing path/message. */
    fun export(context: Context, fileName: String, header: List<String>, rows: List<List<String>>): String {
        val csv = buildString {
            appendLine(header.joinToString(",") { escape(it) })
            rows.forEach { row -> appendLine(row.joinToString(",") { escape(it) }) }
        }

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, "text/csv")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/CAMS")
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            uri?.let {
                resolver.openOutputStream(it)?.use { out -> out.write(csv.toByteArray()) }
            }
            "Saved to Downloads/CAMS/$fileName"
        } else {
            val dir = java.io.File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "CAMS")
            if (!dir.exists()) dir.mkdirs()
            val file = java.io.File(dir, fileName)
            file.writeText(csv)
            "Saved to ${file.absolutePath}"
        }
    }

    private fun escape(field: String): String =
        if (field.contains(",") || field.contains("\"") || field.contains("\n"))
            "\"" + field.replace("\"", "\"\"") + "\""
        else field
}
