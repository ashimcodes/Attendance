package com.cams.attendance.data.dao

import androidx.room.*
import com.cams.attendance.data.entity.AuditLog
import kotlinx.coroutines.flow.Flow

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_logs ORDER BY createdAt DESC LIMIT 200")
    fun getRecent(): Flow<List<AuditLog>>

    @Insert
    suspend fun insert(log: AuditLog): Long
}
