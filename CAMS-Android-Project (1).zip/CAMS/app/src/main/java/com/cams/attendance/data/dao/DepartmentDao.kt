package com.cams.attendance.data.dao

import androidx.room.*
import com.cams.attendance.data.entity.Department
import kotlinx.coroutines.flow.Flow

@Dao
interface DepartmentDao {
    @Query("SELECT * FROM departments ORDER BY name")
    fun getAll(): Flow<List<Department>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(dept: Department): Long

    @Delete
    suspend fun delete(dept: Department)
}
