package com.cams.attendance.ui

import com.cams.attendance.data.entity.User

/** Holds the currently logged-in user for the session (in-memory only). */
object Session {
    var currentUser: User? = null
}
