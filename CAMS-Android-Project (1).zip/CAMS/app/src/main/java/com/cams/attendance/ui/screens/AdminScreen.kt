package com.cams.attendance.ui.screens

import android.content.ContentValues
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.cams.attendance.data.Repository
import com.cams.attendance.data.entity.Role
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

private enum class AdminTab { USERS, AUDIT, BACKUP }

@Composable
fun AdminScreen(repo: Repository) {
    var tab by remember { mutableStateOf(AdminTab.USERS) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Admin", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        TabRow(selectedTabIndex = tab.ordinal) {
            Tab(selected = tab == AdminTab.USERS, onClick = { tab = AdminTab.USERS }, text = { Text("Users") })
            Tab(selected = tab == AdminTab.AUDIT, onClick = { tab = AdminTab.AUDIT }, text = { Text("Audit Log") })
            Tab(selected = tab == AdminTab.BACKUP, onClick = { tab = AdminTab.BACKUP }, text = { Text("Backup") })
        }
        Spacer(Modifier.height(12.dp))

        when (tab) {
            AdminTab.USERS -> UsersTab(repo)
            AdminTab.AUDIT -> AuditTab(repo)
            AdminTab.BACKUP -> BackupTab(repo)
        }
    }
}

@Composable
private fun UsersTab(repo: Repository) {
    val users by repo.users().collectAsState(initial = emptyList())
    var showForm by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        Button(onClick = { showForm = true }) {
            Icon(Icons.Filled.Add, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text("Add User")
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(users, key = { it.id }) { u ->
                ElevatedCard {
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(u.fullName, style = MaterialTheme.typography.titleSmall)
                            Text("${u.username} · ${u.role}", style = MaterialTheme.typography.bodySmall)
                        }
                        if (u.username != "admin") {
                            IconButton(onClick = { scope.launch { repo.deleteUser(u) } }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Delete")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showForm) {
        var username by remember { mutableStateOf("") }
        var password by remember { mutableStateOf("") }
        var fullName by remember { mutableStateOf("") }
        var role by remember { mutableStateOf(Role.TEACHER) }
        var roleMenuOpen by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showForm = false },
            title = { Text("Add User") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(username, { username = it }, label = { Text("Username") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(password, { password = it }, label = { Text("Password") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(fullName, { fullName = it }, label = { Text("Full name") }, modifier = Modifier.fillMaxWidth())
                    Box {
                        OutlinedButton(onClick = { roleMenuOpen = true }, modifier = Modifier.fillMaxWidth()) { Text(role.name) }
                        DropdownMenu(expanded = roleMenuOpen, onDismissRequest = { roleMenuOpen = false }) {
                            Role.entries.forEach { r ->
                                DropdownMenuItem(text = { Text(r.name) }, onClick = { role = r; roleMenuOpen = false })
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { repo.createUser(username, password, fullName, role) }
                    showForm = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showForm = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun AuditTab(repo: Repository) {
    val logs by repo.auditLogs().collectAsState(initial = emptyList())
    val fmt = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items(logs, key = { it.id }) { log ->
            ElevatedCard {
                Column(Modifier.padding(10.dp)) {
                    Text("${log.action}${log.entity?.let { " · $it" } ?: ""}", style = MaterialTheme.typography.bodyMedium)
                    Text(fmt.format(Date(log.createdAt)), style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun BackupTab(repo: Repository) {
    val context = LocalContext.current
    var message by remember { mutableStateOf<String?>(null) }

    Column {
        Text("Export a full backup copy of the local database.", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            message = try {
                val dbFile = context.getDatabasePath("cams.db")
                val fileName = "cams_backup_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.db"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val resolver = context.contentResolver
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                        put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/CAMS")
                    }
                    val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    uri?.let { resolver.openOutputStream(it)?.use { out -> dbFile.inputStream().copyTo(out) } }
                    "Backup saved to Downloads/CAMS/$fileName"
                } else {
                    val dir = java.io.File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "CAMS")
                    if (!dir.exists()) dir.mkdirs()
                    val dest = java.io.File(dir, fileName)
                    dbFile.copyTo(dest, overwrite = true)
                    "Backup saved to ${dest.absolutePath}"
                }
            } catch (e: Exception) {
                "Backup failed: ${e.message}"
            }
        }) { Text("Export Backup") }

        message?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, style = MaterialTheme.typography.bodySmall)
        }
    }
}
