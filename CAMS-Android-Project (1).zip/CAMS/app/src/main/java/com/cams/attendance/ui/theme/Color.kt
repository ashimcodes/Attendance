package com.cams.attendance.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * CAMS design tokens — the "Register" palette.
 * Grounded in the subject: a daily attendance ledger, stamped by hand.
 * Ink for authority, parchment for the page, marigold for the mark,
 * sage/cinnabar for present/absent — the same pair used in every
 * attendance surface in the app (chips, stamps, glows, charts).
 */

// Neutrals
val Ink = Color(0xFF15171F)          // near-black navy — dark surfaces, high-emphasis text
val InkMuted = Color(0xFF3A3F51)     // secondary ink — subdued text on light surfaces
val Parchment = Color(0xFFFBF7EF)    // warm paper white — light surfaces
val ParchmentDim = Color(0xFFF1EADC) // slightly deeper paper — cards on parchment
val Line = Color(0xFFD9D0BC)         // hairline rule color, evokes ledger rules

// Brand
val Indigo = Color(0xFF333B6E)       // primary — deep scholarly indigo
val IndigoLight = Color(0xFF5A649E)  // primary variant for dark mode
val Marigold = Color(0xFFE7A83D)     // accent — stamp-ink amber, used for CTAs & highlights
val MarigoldDeep = Color(0xFFB9822A)

// Semantic (shared everywhere attendance status appears)
val Sage = Color(0xFF3F8F5F)         // present
val SageDeep = Color(0xFF2C6B45)
val Cinnabar = Color(0xFFC64B3C)     // absent
val CinnabarDeep = Color(0xFF9E3A2E)
val Amber = Color(0xFFD69A2D)        // late / pending
