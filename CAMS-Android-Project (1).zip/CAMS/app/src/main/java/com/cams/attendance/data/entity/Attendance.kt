package com.cams.attendance.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class AttendanceStatus { PRESENT, ABSENT, LATE }

@Entity(tableName = "attendance")
data class Attendance(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val classId: Long,
    val subjectId: Long? = null,
    val date: String,          // ISO yyyy-MM-dd
    val status: AttendanceStatus,
    val markedBy: Long? = null,
    val updatedAt: Long = System.currentTimeMillis()
)
