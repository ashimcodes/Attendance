package com.cams.attendance.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Indigo,
    onPrimary = Parchment,
    primaryContainer = ParchmentDim,
    onPrimaryContainer = Indigo,
    secondary = Marigold,
    onSecondary = Ink,
    secondaryContainer = Marigold.copy(alpha = 0.18f),
    onSecondaryContainer = MarigoldDeep,
    background = Parchment,
    onBackground = Ink,
    surface = Parchment,
    onSurface = Ink,
    surfaceVariant = ParchmentDim,
    onSurfaceVariant = InkMuted,
    outline = Line,
    error = Cinnabar,
    onError = Parchment,
    errorContainer = Cinnabar.copy(alpha = 0.15f),
    onErrorContainer = CinnabarDeep
)

private val DarkColors = darkColorScheme(
    primary = IndigoLight,
    onPrimary = Ink,
    primaryContainer = Indigo,
    onPrimaryContainer = Parchment,
    secondary = Marigold,
    onSecondary = Ink,
    secondaryContainer = MarigoldDeep.copy(alpha = 0.35f),
    onSecondaryContainer = Marigold,
    background = Ink,
    onBackground = Parchment,
    surface = Color(0xFF1D2030),
    onSurface = Parchment,
    surfaceVariant = Color(0xFF262A3C),
    onSurfaceVariant = Color(0xFFC9C6BE),
    outline = InkMuted,
    error = Cinnabar,
    onError = Ink,
    errorContainer = CinnabarDeep.copy(alpha = 0.35f),
    onErrorContainer = Color(0xFFF3B9AF)
)

@Composable
fun CAMSTheme(content: @Composable () -> Unit) {
    val colors = if (isSystemInDarkTheme()) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, typography = CAMSTypography, shapes = CAMSShapes, content = content)
}
