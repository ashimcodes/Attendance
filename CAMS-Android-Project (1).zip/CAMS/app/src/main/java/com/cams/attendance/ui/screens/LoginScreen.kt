package com.cams.attendance.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import com.cams.attendance.data.Repository
import com.cams.attendance.ui.components.AuroraBackground
import com.cams.attendance.ui.components.GlassPanel
import com.cams.attendance.ui.theme.DisplayFont
import com.cams.attendance.ui.theme.Ink
import com.cams.attendance.ui.theme.Marigold
import com.cams.attendance.ui.theme.Parchment
import com.cams.attendance.util.BiometricAuth
import com.cams.attendance.util.Prefs
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(repo: Repository, onLoginSuccess: (com.cams.attendance.data.entity.User) -> Unit) {
    val context = LocalContext.current
    val activity = context as? FragmentActivity

    var username by remember { mutableStateOf("admin") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val biometricAvailable = remember(activity) { activity != null && BiometricAuth.isAvailable(activity) }
    val hasRememberedUser = remember { Prefs.getLastUsername(context) != null }

    // Colors chosen explicitly for this screen's dark glass panel — deliberately
    // independent of system light/dark theme, since the panel itself is always
    // a translucent dark surface here. This is what fixes the invisible-text bug:
    // text fields no longer inherit a theme-dependent color that could match the background.
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Parchment,
        unfocusedTextColor = Parchment,
        cursorColor = Marigold,
        focusedBorderColor = Marigold,
        unfocusedBorderColor = Parchment.copy(alpha = 0.35f),
        focusedLabelColor = Marigold,
        unfocusedLabelColor = Parchment.copy(alpha = 0.6f),
        focusedTrailingIconColor = Parchment.copy(alpha = 0.8f),
        unfocusedTrailingIconColor = Parchment.copy(alpha = 0.5f)
    )

    fun doLogin() {
        loading = true
        scope.launch {
            val user = repo.login(username.trim(), password)
            loading = false
            if (user != null) {
                repo.logAction(user.id, "login", "user", user.id)
                Prefs.setLastUsername(context, user.username)
                onLoginSuccess(user)
            } else {
                error = "Invalid username or password"
            }
        }
    }

    fun doBiometricLogin() {
        val act = activity ?: return
        val rememberedUsername = Prefs.getLastUsername(context) ?: return
        BiometricAuth.prompt(
            activity = act,
            onSuccess = {
                scope.launch {
                    val user = repo.findByUsername(rememberedUsername)
                    if (user != null) {
                        repo.logAction(user.id, "login", "user", user.id)
                        onLoginSuccess(user)
                    } else {
                        error = "No saved account for fingerprint sign-in yet — log in with password once first."
                    }
                }
            },
            onError = { msg -> if (msg.isNotBlank() && !msg.contains("password", ignoreCase = true)) error = msg }
        )
    }

    Box(Modifier.fillMaxSize()) {
        AuroraBackground(Modifier.fillMaxSize())

        Column(
            Modifier
                .fillMaxSize()
                .padding(28.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Wax-seal emblem
            Box(
                Modifier.size(76.dp).clip(CircleShape).background(Marigold),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "C",
                    fontFamily = DisplayFont,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.headlineLarge,
                    color = Ink
                )
            }
            Spacer(Modifier.height(20.dp))
            Text(
                "CAMS",
                fontFamily = DisplayFont,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.headlineLarge,
                color = Parchment
            )
            Text(
                "The Class Attendance Register",
                style = MaterialTheme.typography.bodyMedium,
                color = Parchment.copy(alpha = 0.7f)
            )
            Spacer(Modifier.height(32.dp))

            GlassPanel(
                modifier = Modifier.fillMaxWidth().widthIn(max = 420.dp),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(Modifier.padding(24.dp)) {
                    Text(
                        "Sign in",
                        style = MaterialTheme.typography.titleLarge,
                        color = Parchment,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Enter your credentials to open today's register",
                        style = MaterialTheme.typography.bodySmall,
                        color = Parchment.copy(alpha = 0.65f)
                    )
                    Spacer(Modifier.height(20.dp))

                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it; error = null },
                        label = { Text("Username") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = fieldColors
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it; error = null },
                        label = { Text("Password") },
                        singleLine = true,
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    if (passwordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                    contentDescription = if (passwordVisible) "Hide password" else "Show password"
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = fieldColors
                    )
                    error?.let {
                        Spacer(Modifier.height(10.dp))
                        Text(it, color = com.cams.attendance.ui.theme.Cinnabar, style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(Modifier.height(20.dp))

                    Button(
                        onClick = { doLogin() },
                        enabled = !loading,
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Marigold, contentColor = Ink)
                    ) {
                        if (loading) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Ink, strokeWidth = 2.dp)
                        } else {
                            Text("Enter Register", fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.width(8.dp))
                            Icon(Icons.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                    }

                    if (biometricAvailable && hasRememberedUser) {
                        Spacer(Modifier.height(14.dp))
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            HorizontalDivider(Modifier.weight(1f), color = Parchment.copy(alpha = 0.2f))
                            Text("  or  ", style = MaterialTheme.typography.labelSmall, color = Parchment.copy(alpha = 0.5f))
                            HorizontalDivider(Modifier.weight(1f), color = Parchment.copy(alpha = 0.2f))
                        }
                        Spacer(Modifier.height(14.dp))
                        OutlinedButton(
                            onClick = { doBiometricLogin() },
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Parchment)
                        ) {
                            Icon(Icons.Filled.Fingerprint, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Sign in with Fingerprint")
                        }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            Text(
                "Default admin login: admin / admin123",
                style = MaterialTheme.typography.labelMedium,
                color = Parchment.copy(alpha = 0.5f)
            )
        }
    }
}
