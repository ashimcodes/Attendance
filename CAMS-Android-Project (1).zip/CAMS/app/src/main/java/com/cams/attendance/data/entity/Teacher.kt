package com.cams.attendance.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "teachers")
data class Teacher(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fullName: String,
    val email: String? = null,
    val phone: String? = null,
    val departmentId: Long? = null,
    val employeeCode: String? = null
)
