package com.cams.attendance.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class Role { ADMIN, TEACHER }

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String,
    val passwordHash: String,
    val fullName: String,
    val role: Role,
    val teacherId: Long? = null
)
