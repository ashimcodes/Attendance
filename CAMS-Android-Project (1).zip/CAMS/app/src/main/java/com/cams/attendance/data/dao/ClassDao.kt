package com.cams.attendance.data.dao

import androidx.room.*
import com.cams.attendance.data.entity.ClassEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ClassDao {
    @Query("SELECT * FROM classes ORDER BY year DESC, name")
    fun getAll(): Flow<List<ClassEntity>>

    @Query("SELECT * FROM classes WHERE id = :id")
    suspend fun getById(id: Long): ClassEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(c: ClassEntity): Long

    @Delete
    suspend fun delete(c: ClassEntity)
}
