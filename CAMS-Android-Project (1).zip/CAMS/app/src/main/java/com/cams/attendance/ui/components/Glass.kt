package com.cams.attendance.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.cams.attendance.ui.theme.Cinnabar
import com.cams.attendance.ui.theme.Indigo
import com.cams.attendance.ui.theme.Ink
import com.cams.attendance.ui.theme.Marigold
import com.cams.attendance.ui.theme.Sage

/**
 * Frosted-glass surface: translucent gradient fill + a bright hairline border
 * that catches "light", floating with a soft shadow. Meant to sit on top of
 * [AuroraBackground] or another colorful/dark backdrop — against a flat
 * white background it just reads as a faint, quiet card.
 */
@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    tint: Color = Color.White,
    borderAlpha: Float = 0.45f,
    content: @Composable () -> Unit
) {
    Box(
        modifier
            .shadow(
                elevation = 18.dp,
                shape = shape,
                ambientColor = Ink.copy(alpha = 0.4f),
                spotColor = Ink.copy(alpha = 0.5f)
            )
            .clip(shape)
            .background(Ink.copy(alpha = 0.16f))
            .background(
                Brush.linearGradient(
                    colors = listOf(tint.copy(alpha = 0.20f), tint.copy(alpha = 0.06f))
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(tint.copy(alpha = borderAlpha), tint.copy(alpha = 0.05f))
                ),
                shape = shape
            )
    ) {
        content()
    }
}

/**
 * Full-bleed decorative backdrop: deep ink base with soft blurred color blobs
 * (indigo / marigold / sage / cinnabar) — gives glass panels something
 * colorful and atmospheric to refract. Blur only fully renders on
 * Android 12+ (RenderEffect); on older devices the blobs still show as
 * soft-edged glows, just less diffuse — no crash either way.
 */
@Composable
fun AuroraBackground(modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Ink, Color(0xFF1B1E30), Ink)))
    ) {
        Box(
            Modifier
                .size(260.dp)
                .offset(x = (-60).dp, y = (-40).dp)
                .clip(CircleShape)
                .background(Indigo.copy(alpha = 0.55f))
                .blur(90.dp)
        )
        Box(
            Modifier
                .size(220.dp)
                .offset(x = 220.dp, y = 60.dp)
                .clip(CircleShape)
                .background(Marigold.copy(alpha = 0.35f))
                .blur(90.dp)
        )
        Box(
            Modifier
                .size(240.dp)
                .offset(x = (-40).dp, y = 520.dp)
                .clip(CircleShape)
                .background(Sage.copy(alpha = 0.30f))
                .blur(100.dp)
        )
        Box(
            Modifier
                .size(200.dp)
                .offset(x = 240.dp, y = 620.dp)
                .clip(CircleShape)
                .background(Cinnabar.copy(alpha = 0.22f))
                .blur(100.dp)
        )
    }
}
