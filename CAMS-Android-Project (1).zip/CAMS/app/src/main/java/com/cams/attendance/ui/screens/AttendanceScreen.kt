package com.cams.attendance.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.cams.attendance.data.Repository
import com.cams.attendance.data.entity.AttendanceStatus
import com.cams.attendance.data.entity.ClassEntity
import com.cams.attendance.data.entity.User
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttendanceScreen(repo: Repository, user: User) {
    val classes by repo.classes().collectAsState(initial = emptyList())
    var selectedClass by remember { mutableStateOf<ClassEntity?>(null) }
    var classMenuOpen by remember { mutableStateOf(false) }
    var dateStr by remember { mutableStateOf(today()) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    LaunchedEffect(classes) { if (selectedClass == null) selectedClass = classes.firstOrNull() }

    val students by (selectedClass?.let { repo.studentsByClass(it.id) } ?: kotlinx.coroutines.flow.flowOf(emptyList()))
        .collectAsState(initial = emptyList())
    val attendance by (selectedClass?.let { repo.attendanceForClassDate(it.id, dateStr) } ?: kotlinx.coroutines.flow.flowOf(emptyList()))
        .collectAsState(initial = emptyList())
    val statusMap = attendance.associateBy { it.studentId }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Mark Attendance", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))

        Box {
            OutlinedButton(onClick = { classMenuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                Text(selectedClass?.name ?: "Select class")
            }
            DropdownMenu(expanded = classMenuOpen, onDismissRequest = { classMenuOpen = false }) {
                classes.forEach { c ->
                    DropdownMenuItem(text = { Text(c.name) }, onClick = { selectedClass = c; classMenuOpen = false })
                }
            }
        }
        Spacer(Modifier.height(8.dp))

        OutlinedButton(
            onClick = {
                val cal = Calendar.getInstance()
                val parts = dateStr.split("-").map { it.toInt() }
                cal.set(parts[0], parts[1] - 1, parts[2])
                DatePickerDialog(context, { _, y, m, d ->
                    dateStr = String.format("%04d-%02d-%02d", y, m + 1, d)
                }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Filled.CalendarToday, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(dateStr)
        }

        Spacer(Modifier.height(12.dp))
        Text("${students.size} student(s)", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(students, key = { it.id }) { s ->
                val status = statusMap[s.id]?.status
                ElevatedCard {
                    Column(Modifier.padding(12.dp)) {
                        Text(s.fullName, style = MaterialTheme.typography.titleSmall)
                        Text("Roll: ${s.rollNumber}", style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            AttendanceStatus.entries.forEach { st ->
                                FilterChip(
                                    selected = status == st,
                                    onClick = {
                                        val cls = selectedClass ?: return@FilterChip
                                        scope.launch { repo.markAttendance(s.id, cls.id, dateStr, st, user.id) }
                                    },
                                    label = { Text(st.name.lowercase().replaceFirstChar { c -> c.uppercase() }) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
