package com.cams.attendance.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.cams.attendance.data.Repository
import com.cams.attendance.data.entity.ClassEntity
import com.cams.attendance.data.entity.Subject
import com.cams.attendance.ui.Routes
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SwipeFilterScreen(repo: Repository, onStart: (route: String) -> Unit) {
    val classes by repo.classes().collectAsState(initial = emptyList())
    val departments by repo.departments().collectAsState(initial = emptyList())
    val subjects by repo.subjects().collectAsState(initial = emptyList())

    var selectedClass by remember { mutableStateOf<ClassEntity?>(null) }
    var selectedSubject by remember { mutableStateOf<Subject?>(null) }
    var classMenuOpen by remember { mutableStateOf(false) }
    var subjectMenuOpen by remember { mutableStateOf(false) }
    var dateStr by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    val context = LocalContext.current

    LaunchedEffect(classes) { if (selectedClass == null) selectedClass = classes.firstOrNull() }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Box(
            Modifier.size(56.dp).clip(androidx.compose.foundation.shape.CircleShape)
                .background(com.cams.attendance.ui.theme.Marigold),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.TouchApp, contentDescription = null, tint = com.cams.attendance.ui.theme.Ink, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.height(14.dp))
        Text("Swipe Attendance", style = MaterialTheme.typography.headlineSmall, fontFamily = com.cams.attendance.ui.theme.DisplayFont)
        Text(
            "Pick a class and date, then mark attendance one student at a time with swipes.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(24.dp))

        val deptName = departments.find { it.id == selectedClass?.departmentId }?.name ?: "—"
        Text("Department: $deptName", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))

        Box {
            OutlinedButton(onClick = { classMenuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                Text(selectedClass?.let { "${it.name} · ${it.semester} · Sec ${it.section}" } ?: "Select class")
            }
            DropdownMenu(expanded = classMenuOpen, onDismissRequest = { classMenuOpen = false }) {
                classes.forEach { c ->
                    DropdownMenuItem(text = { Text("${c.name} · ${c.semester} · Sec ${c.section}") }, onClick = {
                        selectedClass = c; classMenuOpen = false
                    })
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        Box {
            OutlinedButton(onClick = { subjectMenuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                Text(selectedSubject?.name ?: "Subject (optional)")
            }
            DropdownMenu(expanded = subjectMenuOpen, onDismissRequest = { subjectMenuOpen = false }) {
                DropdownMenuItem(text = { Text("None") }, onClick = { selectedSubject = null; subjectMenuOpen = false })
                subjects.forEach { s ->
                    DropdownMenuItem(text = { Text(s.name) }, onClick = { selectedSubject = s; subjectMenuOpen = false })
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        OutlinedButton(
            onClick = {
                val cal = Calendar.getInstance()
                val parts = dateStr.split("-").map { it.toInt() }
                cal.set(parts[0], parts[1] - 1, parts[2])
                DatePickerDialog(context, { _, y, m, d ->
                    dateStr = String.format("%04d-%02d-%02d", y, m + 1, d)
                }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Filled.CalendarToday, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(dateStr)
        }

        Spacer(Modifier.weight(1f))

        Button(
            onClick = {
                val cls = selectedClass ?: return@Button
                onStart(Routes.swipeAttendance(cls.id, dateStr, selectedSubject?.id))
            },
            enabled = selectedClass != null,
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Icon(Icons.Filled.TouchApp, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Start Swiping", style = MaterialTheme.typography.titleMedium)
        }
        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text("Only students in the selected class will appear.", style = MaterialTheme.typography.labelSmall)
        }
    }
}
