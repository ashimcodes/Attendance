package com.cams.attendance.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.focusTarget
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cams.attendance.data.Repository
import com.cams.attendance.data.StudentAttendanceSummary
import com.cams.attendance.data.entity.AttendanceStatus
import com.cams.attendance.data.entity.ClassEntity
import com.cams.attendance.data.entity.Department
import com.cams.attendance.data.entity.Student
import com.cams.attendance.data.entity.User
import com.cams.attendance.util.CsvExporter
import com.cams.attendance.util.PdfExporter
import com.cams.attendance.ui.theme.Sage
import com.cams.attendance.ui.theme.Cinnabar
import com.cams.attendance.ui.theme.DataFont
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

private data class HistoryEntry(val studentId: Long, val wasPresent: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SwipeAttendanceScreen(
    repo: Repository,
    user: User,
    classId: Long,
    dateStr: String,
    subjectId: Long?,
    onFinishToDashboard: () -> Unit,
    onEditManually: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val focusRequester = remember { FocusRequester() }

    var cls by remember { mutableStateOf<ClassEntity?>(null) }
    var dept by remember { mutableStateOf<Department?>(null) }
    var students by remember { mutableStateOf<List<Student>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }

    var index by remember { mutableIntStateOf(0) }
    var presentCount by remember { mutableIntStateOf(0) }
    var absentCount by remember { mutableIntStateOf(0) }
    val history = remember { mutableStateListOf<HistoryEntry>() }
    val skipped = remember { mutableStateListOf<Student>() }
    var reviewingSkipped by remember { mutableStateOf(false) }
    var finished by remember { mutableStateOf(false) }

    var snackMsg by remember { mutableStateOf<String?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }
    var detailStudent by remember { mutableStateOf<Student?>(null) }

    LaunchedEffect(classId) {
        cls = repo.getClass(classId)
        val list = repo.departments().first()
        dept = list.find { it.id == cls?.departmentId }
    }
    LaunchedEffect(classId) {
        val list = repo.studentsByClass(classId).first()
        students = list.sortedBy { s -> s.rollNumber }
        loaded = true
    }
    LaunchedEffect(Unit) { focusRequester.requestFocus() }

    val remaining = (students.size - index).coerceAtLeast(0)

    fun currentStudent(): Student? = students.getOrNull(index)

    fun advance() {
        if (index < students.lastIndex) {
            index += 1
        } else if (skipped.isNotEmpty() && !reviewingSkipped) {
            reviewingSkipped = true
            students = skipped.toList()
            skipped.clear()
            index = 0
        } else {
            finished = true
        }
    }

    fun mark(status: AttendanceStatus) {
        val s = currentStudent() ?: return
        scope.launch {
            repo.markAttendance(s.id, classId, dateStr, status, user.id)
            history.add(HistoryEntry(s.id, status == AttendanceStatus.PRESENT))
            if (status == AttendanceStatus.PRESENT) presentCount++ else absentCount++
            snackMsg = "${s.fullName} marked ${status.name.lowercase()}"
            advance()
        }
    }

    fun skip() {
        val s = currentStudent() ?: return
        if (!reviewingSkipped) skipped.add(s)
        snackMsg = "Skipped ${s.fullName}"
        advance()
    }

    fun undo() {
        if (history.isEmpty()) {
            snackMsg = "Nothing to undo"
            return
        }
        val last = history.removeLast()
        scope.launch {
            repo.unmarkAttendance(last.studentId, classId, dateStr)
            if (last.wasPresent) presentCount = (presentCount - 1).coerceAtLeast(0)
            else absentCount = (absentCount - 1).coerceAtLeast(0)
            if (index > 0) index -= 1
            finished = false
            snackMsg = "Undid last action"
        }
    }

    val totalPercent = if (presentCount + absentCount > 0) (presentCount * 100 / (presentCount + absentCount)) else 0

    Box(
        Modifier
            .fillMaxSize()
            .focusRequester(focusRequester)
            .focusTarget()
            .onKeyEvent { event ->
                if (event.type != KeyEventType.KeyDown) return@onKeyEvent false
                when (event.key) {
                    Key.DirectionUp -> { mark(AttendanceStatus.PRESENT); true }
                    Key.DirectionDown -> { mark(AttendanceStatus.ABSENT); true }
                    Key.DirectionRight -> { skip(); true }
                    Key.DirectionLeft -> { if (index > 0) index -= 1; true }
                    else -> false
                }
            }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(if (reviewingSkipped) "Reviewing skipped" else "Swipe Attendance") },
                    navigationIcon = {
                        IconButton(onClick = onFinishToDashboard) {
                            Icon(Icons.Filled.Close, contentDescription = "Close")
                        }
                    },
                    actions = {
                        IconButton(onClick = { undo() }) {
                            Icon(Icons.Filled.Undo, contentDescription = "Undo")
                        }
                    }
                )
            },
            snackbarHost = { SnackbarHost(snackbarHostState) }
        ) { padding ->
            snackMsg?.let {
                LaunchedEffect(it) { snackbarHostState.showSnackbar(it); snackMsg = null }
            }

            Box(Modifier.padding(padding).fillMaxSize()) {
                if (!loaded) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                } else if (students.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No students in this class yet.")
                    }
                } else if (finished) {
                    CompletionScreen(
                        className = cls?.name ?: "",
                        dateStr = dateStr,
                        present = presentCount,
                        absent = absentCount,
                        onReview = onEditManually,
                        onEdit = onEditManually,
                        onDashboard = onFinishToDashboard,
                        repo = repo,
                        classId = classId
                    )
                } else {
                    Column(Modifier.fillMaxSize()) {
                        ProgressPanel(
                            current = index + 1,
                            total = students.size,
                            present = presentCount,
                            absent = absentCount,
                            remaining = remaining,
                            percent = totalPercent,
                            reviewing = reviewingSkipped
                        )

                        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            currentStudent()?.let { student ->
                                key(student.id, index) {
                                    SwipeableStudentCard(
                                        student = student,
                                        className = cls?.name ?: "",
                                        departmentName = dept?.name ?: "",
                                        semester = cls?.semester ?: "",
                                        section = cls?.section ?: "",
                                        dateStr = dateStr,
                                        repo = repo,
                                        onSwipeUp = { mark(AttendanceStatus.PRESENT) },
                                        onSwipeDown = { mark(AttendanceStatus.ABSENT) },
                                        onSwipeLeft = { skip() },
                                        onSwipeRight = { detailStudent = student }
                                    )
                                }
                            }
                        }

                        Row(
                            Modifier.fillMaxWidth().padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            RoundIconButton(Icons.Filled.SkipNext, "Skip", MaterialTheme.colorScheme.secondary) { skip() }
                            RoundIconButton(Icons.Filled.Close, "Absent", Cinnabar) { mark(AttendanceStatus.ABSENT) }
                            RoundIconButton(Icons.Filled.Info, "Details", MaterialTheme.colorScheme.primary) {
                                currentStudent()?.let { detailStudent = it }
                            }
                            RoundIconButton(Icons.Filled.Check, "Present", Sage) { mark(AttendanceStatus.PRESENT) }
                        }
                    }
                }
            }
        }
    }

    detailStudent?.let { s ->
        StudentDetailSheet(student = s, repo = repo, onDismiss = { detailStudent = null })
    }
}

@Composable
private fun RoundIconButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, color: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        FilledIconButton(
            onClick = onClick,
            modifier = Modifier.size(56.dp),
            colors = IconButtonDefaults.filledIconButtonColors(containerColor = color)
        ) {
            Icon(icon, contentDescription = label, tint = Color.White)
        }
        Spacer(Modifier.height(4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun ProgressPanel(
    current: Int,
    total: Int,
    present: Int,
    absent: Int,
    remaining: Int,
    percent: Int,
    reviewing: Boolean
) {
    ElevatedCard(Modifier.fillMaxWidth().padding(12.dp)) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    if (reviewing) "Reviewing $current of $total" else "Student $current of $total",
                    style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold
                )
                Text("$percent% present", style = MaterialTheme.typography.titleSmall)
            }
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { if (total > 0) current.toFloat() / total else 0f },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(4.dp))
            )
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                StatChip("Present", present, Sage)
                StatChip("Absent", absent, Cinnabar)
                StatChip("Remaining", remaining, MaterialTheme.colorScheme.secondary)
            }
        }
    }
}

@Composable
private fun StatChip(label: String, value: Int, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(4.dp))
        Text("$label: $value", style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun SwipeableStudentCard(
    student: Student,
    className: String,
    departmentName: String,
    semester: String,
    section: String,
    dateStr: String,
    repo: Repository,
    onSwipeUp: () -> Unit,
    onSwipeDown: () -> Unit,
    onSwipeLeft: () -> Unit,
    onSwipeRight: () -> Unit
) {
    val offsetX = remember { Animatable(0f) }
    val offsetY = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var flipped by remember { mutableStateOf(false) }
    val rotationY by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (flipped) 180f else 0f,
        animationSpec = tween(420),
        label = "flip"
    )

    var summary by remember { mutableStateOf<StudentAttendanceSummary?>(null) }
    LaunchedEffect(student.id) { summary = repo.studentSummary(student.id) }

    val threshold = 260f
    val dragProgressY = (offsetY.value / threshold).coerceIn(-1f, 1f)
    val liveRotationZ = (offsetX.value / 40f).coerceIn(-16f, 16f)

    val glowColor = when {
        dragProgressY < -0.15f -> Sage.copy(alpha = (-dragProgressY).coerceIn(0f, 1f))
        dragProgressY > 0.15f -> Cinnabar.copy(alpha = dragProgressY.coerceIn(0f, 1f))
        else -> Color.Transparent
    }

    AnimatedVisibility(visible = true, enter = fadeIn(tween(280)) + scaleIn(initialScale = 0.9f, animationSpec = tween(280))) {
        Box(
            Modifier
                .width(320.dp)
                .height(460.dp)
                .graphicsLayer {
                    translationX = offsetX.value
                    translationY = offsetY.value
                    rotationZ = liveRotationZ
                }
                .pointerInput(student.id) {
                    detectDragGestures(
                        onDrag = { change, drag ->
                            change.consume()
                            scope.launch {
                                offsetX.snapTo(offsetX.value + drag.x)
                                offsetY.snapTo(offsetY.value + drag.y)
                            }
                        },
                        onDragEnd = {
                            val x = offsetX.value
                            val y = offsetY.value
                            scope.launch {
                                when {
                                    y < -threshold -> {
                                        offsetY.animateTo(-1400f, tween(220)); onSwipeUp()
                                    }
                                    y > threshold -> {
                                        offsetY.animateTo(1400f, tween(220)); onSwipeDown()
                                    }
                                    x < -threshold -> {
                                        offsetX.animateTo(-1400f, tween(220)); onSwipeLeft()
                                    }
                                    x > threshold -> {
                                        offsetX.animateTo(1400f, tween(220)); onSwipeRight()
                                        offsetX.animateTo(0f, spring(Spring.DampingRatioMediumBouncy))
                                    }
                                    else -> {
                                        offsetX.animateTo(0f, spring(Spring.DampingRatioMediumBouncy))
                                        offsetY.animateTo(0f, spring(Spring.DampingRatioMediumBouncy))
                                    }
                                }
                            }
                        }
                    )
                }
                .pointerInput(student.id) {
                    detectTapGestures(onTap = { flipped = !flipped })
                }
        ) {
            ElevatedCard(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { this.rotationY = rotationY; cameraDistance = 24f }
                    .border(3.dp, glowColor, RoundedCornerShape(20.dp)),
                shape = RoundedCornerShape(20.dp)
            ) {
                if (rotationY <= 90f) {
                    CardFront(student, className, departmentName, semester, section, dateStr)
                } else {
                    Box(Modifier.graphicsLayer { this.rotationY = 180f }) {
                        CardBack(student, summary)
                    }
                }
            }

            if (dragProgressY < -0.2f) {
                SwipeStamp(text = "PRESENT", color = Sage, alpha = -dragProgressY, modifier = Modifier.align(Alignment.TopCenter).padding(top = 24.dp))
            }
            if (dragProgressY > 0.2f) {
                SwipeStamp(text = "ABSENT", color = Cinnabar, alpha = dragProgressY, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 24.dp))
            }
        }
    }
}

@Composable
private fun SwipeStamp(text: String, color: Color, alpha: Float, modifier: Modifier = Modifier) {
    val angle = if (text == "PRESENT") -14f else 10f
    Box(
        modifier
            .graphicsLayer {
                this.alpha = alpha.coerceIn(0f, 1f)
                rotationZ = angle
                scaleX = 0.9f + alpha.coerceIn(0f, 1f) * 0.15f
                scaleY = 0.9f + alpha.coerceIn(0f, 1f) * 0.15f
            }
            .border(3.dp, color, RoundedCornerShape(6.dp))
            .padding(3.dp)
            .border(1.dp, color, RoundedCornerShape(4.dp))
            .background(color.copy(alpha = 0.12f))
            .padding(horizontal = 18.dp, vertical = 8.dp)
    ) {
        Text(
            text,
            color = color,
            fontFamily = DataFont,
            fontWeight = FontWeight.Bold,
            letterSpacing = 4.sp,
            style = MaterialTheme.typography.titleMedium
        )
    }
}

@Composable
private fun CardFront(student: Student, className: String, departmentName: String, semester: String, section: String, dateStr: String) {
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        AvatarCircle(student.fullName, size = 96.dp)
        Spacer(Modifier.height(14.dp))
        Text(student.fullName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Roll No: ${student.rollNumber} · ${student.studentCode}", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(16.dp))
        Divider()
        Spacer(Modifier.height(12.dp))
        InfoRow("Class", className)
        InfoRow("Department", departmentName)
        InfoRow("Semester", semester)
        InfoRow("Section", section)
        InfoRow("Date", dateStr)
        Spacer(Modifier.weight(1f))
        Text("Tap card to flip · Drag to swipe", style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun CardBack(student: Student, summary: StudentAttendanceSummary?) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Student Details", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        InfoRow("Parent Name", student.parentName ?: "—")
        InfoRow("Parent Phone", student.parentPhone ?: "—")
        InfoRow("Overall Attendance", "${summary?.overallPercent ?: 0}%")
        InfoRow("Last Marked", summary?.lastDate ?: "—")
        InfoRow("Last Status", summary?.lastStatus?.name ?: "—")
        Spacer(Modifier.height(8.dp))
        Text("Remarks", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
        Text(student.remarks ?: "No remarks", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.weight(1f))
        Text("Tap to flip back", style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun AvatarCircle(name: String, size: androidx.compose.ui.unit.Dp) {
    val initials = name.split(" ").filter { it.isNotBlank() }.take(2).joinToString("") { it.first().uppercase() }
    Box(
        Modifier.size(size).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center
    ) {
        Text(initials, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StudentDetailSheet(student: Student, repo: Repository, onDismiss: () -> Unit) {
    var summary by remember { mutableStateOf<StudentAttendanceSummary?>(null) }
    LaunchedEffect(student.id) { summary = repo.studentSummary(student.id) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(20.dp)) {
            Text(student.fullName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            InfoRow("Roll Number", student.rollNumber)
            InfoRow("Student Code", student.studentCode)
            InfoRow("Email", student.email ?: "—")
            InfoRow("Phone", student.phone ?: "—")
            InfoRow("Parent Name", student.parentName ?: "—")
            InfoRow("Parent Phone", student.parentPhone ?: "—")
            InfoRow("Overall Attendance", "${summary?.overallPercent ?: 0}%")
            InfoRow("Last Marked", summary?.lastDate ?: "—")
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun CompletionScreen(
    className: String,
    dateStr: String,
    present: Int,
    absent: Int,
    onReview: () -> Unit,
    onEdit: () -> Unit,
    onDashboard: () -> Unit,
    repo: Repository,
    classId: Long
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val total = present + absent
    val pct = if (total > 0) (present * 100 / total) else 0

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            Modifier.padding(24.dp).widthIn(max = 420.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AnimatedVisibility(visible = true, enter = fadeIn(tween(400)) + scaleIn(initialScale = 0.8f)) {
                Icon(
                    Icons.Filled.CheckCircle, contentDescription = null,
                    modifier = Modifier.size(72.dp), tint = Sage
                )
            }
            Spacer(Modifier.height(12.dp))
            Text("Attendance Complete!", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("$className · $dateStr", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(20.dp))

            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    InfoRow("Total Students", "$total")
                    InfoRow("Present", "$present")
                    InfoRow("Absent", "$absent")
                    InfoRow("Attendance %", "$pct%")
                }
            }
            Spacer(Modifier.height(20.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onReview, modifier = Modifier.weight(1f)) { Text("Review") }
                OutlinedButton(onClick = onEdit, modifier = Modifier.weight(1f)) { Text("Edit") }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        scope.launch {
                            val students = repo.studentsByClass(classId).first()
                            val records = repo.reportForClass(classId, dateStr, dateStr)
                            val rows = students.map { s ->
                                val rec = records.find { it.studentId == s.id }
                                listOf(s.fullName, s.rollNumber, rec?.status?.name ?: "—")
                            }
                            CsvExporter.export(context, "swipe_attendance_$dateStr.csv", listOf("Student", "Roll No", "Status"), rows)
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("Export CSV") }

                Button(
                    onClick = {
                        scope.launch {
                            val students = repo.studentsByClass(classId).first()
                            val records = repo.reportForClass(classId, dateStr, dateStr)
                            val rows = students.map { s ->
                                val rec = records.find { it.studentId == s.id }
                                listOf(s.fullName, s.rollNumber, rec?.status?.name ?: "—")
                            }
                            PdfExporter.export(context, "swipe_attendance_$dateStr.pdf", "Attendance — $className ($dateStr)", listOf("Student", "Roll", "Status"), rows)
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("Export PDF") }
            }
            Spacer(Modifier.height(16.dp))
            TextButton(onClick = onDashboard) { Text("Return to Dashboard") }
        }
    }
}
