package com.cams.attendance.data.dao

import androidx.room.*
import com.cams.attendance.data.entity.Student
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentDao {
    @Query("SELECT * FROM students ORDER BY fullName")
    fun getAll(): Flow<List<Student>>

    @Query("SELECT * FROM students WHERE classId = :classId ORDER BY rollNumber")
    fun getByClass(classId: Long): Flow<List<Student>>

    @Query("SELECT * FROM students WHERE fullName LIKE '%' || :q || '%' OR rollNumber LIKE '%' || :q || '%' OR studentCode LIKE '%' || :q || '%'")
    fun search(q: String): Flow<List<Student>>

    @Query("SELECT * FROM students WHERE id = :id")
    suspend fun getById(id: Long): Student?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(s: Student): Long

    @Delete
    suspend fun delete(s: Student)
}
