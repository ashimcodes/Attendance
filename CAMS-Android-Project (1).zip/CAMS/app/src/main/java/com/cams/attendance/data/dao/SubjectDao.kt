package com.cams.attendance.data.dao

import androidx.room.*
import com.cams.attendance.data.entity.Subject
import kotlinx.coroutines.flow.Flow

@Dao
interface SubjectDao {
    @Query("SELECT * FROM subjects ORDER BY name")
    fun getAll(): Flow<List<Subject>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(s: Subject): Long

    @Delete
    suspend fun delete(s: Subject)
}
