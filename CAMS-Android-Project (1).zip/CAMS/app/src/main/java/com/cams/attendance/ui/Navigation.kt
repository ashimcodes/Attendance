package com.cams.attendance.ui

object Routes {
    const val LOGIN = "login"
    const val DASHBOARD = "dashboard"
    const val STUDENTS = "students"
    const val TEACHERS = "teachers"
    const val CLASSES = "classes"
    const val ATTENDANCE = "attendance"
    const val REPORTS = "reports"
    const val ADMIN = "admin"
    const val SWIPE_FILTERS = "swipe_filters"
    const val SWIPE_ATTENDANCE = "swipe_attendance/{classId}/{date}/{subjectId}"

    fun swipeAttendance(classId: Long, date: String, subjectId: Long?): String =
        "swipe_attendance/$classId/$date/${subjectId ?: 0}"
}
