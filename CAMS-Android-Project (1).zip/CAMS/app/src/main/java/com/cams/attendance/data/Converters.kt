package com.cams.attendance.data

import androidx.room.TypeConverter
import com.cams.attendance.data.entity.AttendanceStatus
import com.cams.attendance.data.entity.Role

class Converters {
    @TypeConverter
    fun fromAttendanceStatus(s: AttendanceStatus): String = s.name

    @TypeConverter
    fun toAttendanceStatus(s: String): AttendanceStatus = AttendanceStatus.valueOf(s)

    @TypeConverter
    fun fromRole(r: Role): String = r.name

    @TypeConverter
    fun toRole(r: String): Role = Role.valueOf(r)
}
