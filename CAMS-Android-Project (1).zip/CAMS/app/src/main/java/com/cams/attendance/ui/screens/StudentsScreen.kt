package com.cams.attendance.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cams.attendance.data.Repository
import com.cams.attendance.data.entity.ClassEntity
import com.cams.attendance.data.entity.Department
import com.cams.attendance.data.entity.Student
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentsScreen(repo: Repository) {
    val students by repo.students().collectAsState(initial = emptyList())
    val departments by repo.departments().collectAsState(initial = emptyList())
    val classes by repo.classes().collectAsState(initial = emptyList())
    var editing by remember { mutableStateOf<Student?>(null) }
    var showForm by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { editing = null; showForm = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Add student")
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            Text("Students (${students.size})", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(students, key = { it.id }) { s ->
                    val className = classes.find { it.id == s.classId }?.name ?: "—"
                    ElevatedCard {
                        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(s.fullName, style = MaterialTheme.typography.titleMedium)
                                Text("Roll: ${s.rollNumber} · $className", style = MaterialTheme.typography.bodySmall)
                                Text("Code: ${s.studentCode}", style = MaterialTheme.typography.bodySmall)
                            }
                            Row {
                                IconButton(onClick = { editing = s; showForm = true }) {
                                    Icon(Icons.Filled.Edit, contentDescription = "Edit")
                                }
                                IconButton(onClick = { scope.launch { repo.deleteStudent(s) } }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Delete")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showForm) {
        StudentFormDialog(
            student = editing,
            departments = departments,
            classes = classes,
            onDismiss = { showForm = false },
            onSave = { s -> scope.launch { repo.saveStudent(s) }; showForm = false }
        )
    }
}

@Composable
private fun StudentFormDialog(
    student: Student?,
    departments: List<Department>,
    classes: List<ClassEntity>,
    onDismiss: () -> Unit,
    onSave: (Student) -> Unit
) {
    var fullName by remember { mutableStateOf(student?.fullName ?: "") }
    var rollNumber by remember { mutableStateOf(student?.rollNumber ?: "") }
    var studentCode by remember { mutableStateOf(student?.studentCode ?: "") }
    var email by remember { mutableStateOf(student?.email ?: "") }
    var phone by remember { mutableStateOf(student?.phone ?: "") }
    var selectedClass by remember { mutableStateOf(classes.find { it.id == student?.classId } ?: classes.firstOrNull()) }
    var classMenuOpen by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (student == null) "Add Student" else "Edit Student") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(fullName, { fullName = it }, label = { Text("Full name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(rollNumber, { rollNumber = it }, label = { Text("Roll number") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(studentCode, { studentCode = it }, label = { Text("Student code") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(email, { email = it }, label = { Text("Email (optional)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(phone, { phone = it }, label = { Text("Phone (optional)") }, modifier = Modifier.fillMaxWidth())

                Box {
                    OutlinedButton(onClick = { classMenuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(selectedClass?.name ?: "Select class")
                    }
                    DropdownMenu(expanded = classMenuOpen, onDismissRequest = { classMenuOpen = false }) {
                        classes.forEach { c ->
                            DropdownMenuItem(text = { Text(c.name) }, onClick = { selectedClass = c; classMenuOpen = false })
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val cls = selectedClass ?: return@TextButton
                onSave(
                    Student(
                        id = student?.id ?: 0,
                        studentCode = studentCode,
                        fullName = fullName,
                        rollNumber = rollNumber,
                        departmentId = cls.departmentId,
                        classId = cls.id,
                        email = email.ifBlank { null },
                        phone = phone.ifBlank { null }
                    )
                )
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
