package com.cams.attendance.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cams.attendance.data.Repository
import com.cams.attendance.data.entity.ClassEntity
import com.cams.attendance.data.entity.Department
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClassesScreen(repo: Repository) {
    val classes by repo.classes().collectAsState(initial = emptyList())
    val departments by repo.departments().collectAsState(initial = emptyList())
    var showForm by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showForm = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Add class")
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            Text("Classes (${classes.size})", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(classes, key = { it.id }) { c ->
                    val dept = departments.find { it.id == c.departmentId }?.name ?: "—"
                    ElevatedCard {
                        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(c.name, style = MaterialTheme.typography.titleMedium)
                                Text("$dept · ${c.semester} · Section ${c.section} · Year ${c.year}", style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton(onClick = { scope.launch { repo.deleteClass(c) } }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Delete")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showForm) {
        ClassFormDialog(
            departments = departments,
            onDismiss = { showForm = false },
            onSave = { c -> scope.launch { repo.saveClass(c) }; showForm = false }
        )
    }
}

@Composable
private fun ClassFormDialog(departments: List<Department>, onDismiss: () -> Unit, onSave: (ClassEntity) -> Unit) {
    var name by remember { mutableStateOf("") }
    var semester by remember { mutableStateOf("Semester 1") }
    var section by remember { mutableStateOf("A") }
    var year by remember { mutableStateOf("1") }
    var selectedDept by remember { mutableStateOf(departments.firstOrNull()) }
    var deptMenuOpen by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Class") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Class name") }, modifier = Modifier.fillMaxWidth())
                Box {
                    OutlinedButton(onClick = { deptMenuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(selectedDept?.name ?: "Select department")
                    }
                    DropdownMenu(expanded = deptMenuOpen, onDismissRequest = { deptMenuOpen = false }) {
                        departments.forEach { d ->
                            DropdownMenuItem(text = { Text(d.name) }, onClick = { selectedDept = d; deptMenuOpen = false })
                        }
                    }
                }
                OutlinedTextField(semester, { semester = it }, label = { Text("Semester") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(section, { section = it }, label = { Text("Section") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(year, { year = it.filter { ch -> ch.isDigit() } }, label = { Text("Year") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val dept = selectedDept ?: return@TextButton
                onSave(
                    ClassEntity(
                        name = name.ifBlank { "$semester - $section" },
                        departmentId = dept.id,
                        semester = semester,
                        section = section,
                        year = year.toIntOrNull() ?: 1
                    )
                )
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
