package com.cams.attendance.data.dao

import androidx.room.*
import com.cams.attendance.data.entity.Teacher
import kotlinx.coroutines.flow.Flow

@Dao
interface TeacherDao {
    @Query("SELECT * FROM teachers ORDER BY fullName")
    fun getAll(): Flow<List<Teacher>>

    @Query("SELECT * FROM teachers WHERE id = :id")
    suspend fun getById(id: Long): Teacher?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(t: Teacher): Long

    @Delete
    suspend fun delete(t: Teacher)
}
