package com.cams.attendance.util

import android.content.ContentValues
import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Environment
import android.provider.MediaStore

object PdfExporter {
    /** Renders a simple tabular report to a PDF and saves it to Downloads/CAMS/<fileName>. */
    fun export(context: Context, fileName: String, title: String, header: List<String>, rows: List<List<String>>): String {
        val doc = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        var page = doc.startPage(pageInfo)
        var canvas = page.canvas

        val titlePaint = Paint().apply { textSize = 18f; isFakeBoldText = true }
        val headerPaint = Paint().apply { textSize = 11f; isFakeBoldText = true }
        val bodyPaint = Paint().apply { textSize = 10f }

        var y = 40f
        canvas.drawText(title, 32f, y, titlePaint)
        y += 30f

        val colWidth = (pageWidth - 64) / header.size.coerceAtLeast(1)
        header.forEachIndexed { i, h -> canvas.drawText(h, 32f + i * colWidth, y, headerPaint) }
        y += 18f

        var pageNum = 1
        rows.forEach { row ->
            if (y > pageHeight - 40) {
                doc.finishPage(page)
                pageNum++
                pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create()
                page = doc.startPage(pageInfo)
                canvas = page.canvas
                y = 40f
            }
            row.forEachIndexed { i, cell -> canvas.drawText(cell, 32f + i * colWidth, y, bodyPaint) }
            y += 16f
        }
        doc.finishPage(page)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/CAMS")
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            uri?.let { resolver.openOutputStream(it)?.use { out -> doc.writeTo(out) } }
        } else {
            val dir = java.io.File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "CAMS")
            if (!dir.exists()) dir.mkdirs()
            val file = java.io.File(dir, fileName)
            file.outputStream().use { doc.writeTo(it) }
        }
        doc.close()
        return "Saved to Downloads/CAMS/$fileName"
    }
}
