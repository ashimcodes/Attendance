package com.music.bitchord.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.EaseOutCubic
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import com.music.bitchord.R
import kotlinx.coroutines.delay

/**
 * The animated, Ash Music–branded launch screen shown right after the system
 * splash ([Theme.AshMusic.Splash][R.style]) hands off to Compose. Runs once
 * per cold start, then calls [onFinished] so the caller can cross-fade into
 * the real app — see the `showSplash` gate in `MainActivity`.
 *
 * Kept intentionally short (~1.6s total): background fade, logo scale/fade
 * with a soft glow pulse behind it, a beat of haptic feedback at the moment
 * the logo settles, then a fade out. The provided artwork is a single flattened
 * 9:16 image (logo, EQ bars and the "Created By Ashim" credit all baked in
 * together), so rather than trying to pull those apart it is treated as one
 * design and animated as a whole — scaled/faded in together the way the
 * reference image itself composes them.
 *
 * [ContentScale.Fit] on a black canvas — never [ContentScale.Crop] — so the
 * 9:16 art is letterboxed rather than cropped on phones with a different
 * aspect ratio. Because the image's own background is close to pure black,
 * the letterbox bars are invisible in practice, and nothing important (the
 * mark, the credit line) is ever cut off or pushed under a cutout or nav bar.
 */
private const val BG_FADE_MS = 220
private const val LOGO_ANIM_MS = 650
private const val HOLD_MS = 480
private const val EXIT_FADE_MS = 380

@Composable
fun AshMusicSplash(onFinished: () -> Unit) {
    val haptic = LocalHapticFeedback.current

    var bgAlpha by remember { mutableFloatStateOf(0f) }
    val logoAlpha = remember { Animatable(0f) }
    val logoScale = remember { Animatable(0.86f) }
    var exiting by remember { mutableFloatStateOf(1f) }

    // Slow, subtle breathing glow behind the mark — runs continuously for as
    // long as the splash is on screen, independent of the entrance timeline.
    val infiniteTransition = rememberInfiniteTransition(label = "splashGlow")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.65f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "glowAlpha",
    )

    LaunchedEffect(Unit) {
        // 1. Background fades in first so there's never a hard black cut.
        val bgStep = 16
        val steps = BG_FADE_MS / bgStep
        repeat(steps) { i ->
            bgAlpha = (i + 1f) / steps
            delay(bgStep.toLong())
        }
        bgAlpha = 1f

        // 2. The mark itself scales and fades into place.
        logoAlpha.animateTo(1f, tween(LOGO_ANIM_MS, easing = EaseOutCubic))
    }

    LaunchedEffect(Unit) {
        // Runs alongside the alpha animation above so scale and fade land
        // together rather than one trailing the other.
        logoScale.animateTo(1f, tween(LOGO_ANIM_MS, easing = EaseOutCubic))
        // 3. The key animation moment — the mark has just settled into place.
        // One short, gentle tick, not a buzz: performHapticFeedback quietly
        // no-ops on devices/settings without haptics, so nothing else is needed
        // to fail gracefully.
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)

        // 4. Hold briefly so the design registers, then hand off.
        delay(HOLD_MS.toLong())
        val exitStep = 16
        val exitSteps = EXIT_FADE_MS / exitStep
        repeat(exitSteps) { i ->
            exiting = 1f - (i + 1f) / exitSteps
            delay(exitStep.toLong())
        }
        exiting = 0f
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .alpha(bgAlpha * exiting),
        contentAlignment = Alignment.Center,
    ) {
        // Soft radial glow behind the artwork — purely additive polish, never
        // part of the artwork's own hit area or safe zone.
        Box(
            modifier = Modifier
                .fillMaxSize()
                .alpha(glowAlpha * logoAlpha.value)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF7C3AED).copy(alpha = 0.28f),
                            Color.Transparent,
                        ),
                        center = Offset.Unspecified,
                        radius = 900f,
                    ),
                ),
        )

        Image(
            painter = painterResource(R.drawable.splash_ash_music),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .scale(logoScale.value)
                .alpha(logoAlpha.value),
        )
    }
}
