# Ash Music rebrand — what changed

This is the original BitChord project (GPL-3.0), rebranded to **Ash Music**. Everything
below was done at the source level; **this could not be compiled or run in the
environment that made these changes** (no Android SDK, no network access), so please
open it in Android Studio and build before relying on it.

## Done

- **App name**: `app_name` is "Ash Music" in all 10 locales. Fixed a few stray
  lowercase "bitchord" strings that had been missed in notification text
  (update-available/downloading/ready/failed) and a widget label, across all locales.
- **App icon**: your provided icon is now the launcher icon at every density
  (legacy `ic_launcher`/`ic_launcher_round`, adaptive icon foreground+background,
  and the 512×512 Play Store icon). The adaptive icon background is solid black
  to match the icon's own background; the old vector foreground/background
  drawables were removed since nothing else referenced them.
- **Splash screen**: `ui/AshMusicSplash.kt` — a Compose overlay shown once per
  cold start on top of the real UI. Background fade → your splash image
  scale/fades in → a soft pulsing glow behind it → one subtle haptic tick at
  the moment the mark settles → brief hold → fade out into the app. It uses
  `ContentScale.Fit` (never crop) so the 9:16 artwork is never cropped or
  stretched — it's letterboxed against black instead, which is invisible in
  practice since the art's own background is near-black. Wired up with
  `androidx.core.splashscreen` (`Theme.AshMusic.Splash`, applied only to
  `MainActivity`) so there's no blank flash before Compose even loads.
- **Settings → About Ash Music**: new row + `ui/components/AboutAshMusicDialog.kt`.
  Placeholder fields (Developed by Ashim / bio placeholder / version / ©
  Ashim) are grouped in one `AboutInfo` object at the top of that file —
  that's the one spot to edit once your real bio copy is ready.
- **Removed** the GitHub / Developer / Discord links from the Settings footer.
- Swept for other visible old-branding leaks and fixed them:
  - "Counted on device with BitChord" baked into the shareable Replay poster
  - the `Pictures/BitChord` save folder + filename for shared Replay posters
  - a few "No downloaded tracks in Music/BitChord" error strings that had
    drifted out of sync with the actual (already-renamed) download folder
  - backup import/export error copy ("...doesn't look like a BitChord backup", etc.)
  - the Discord Rich Presence button label ("Visit BitChord" → "Visit Ash Music")

## Left alone on purpose (not user-facing)

- Internal names that users never see: log tags, `BitChordTheme`/`BitChordIcons`/
  `BitChordApp`/`BitChordApplication` class names, the `Theme.BitChord` style
  identifier, GPL copyright headers in source comments, and the network
  User-Agent strings sent to Last.fm/LrcLib/ListenBrainz. Renaming these is
  cosmetic-only and risked introducing build breakage for no visible benefit.

## Needs your input before this is fully "yours"

- **Discord Rich Presence** (`data/discord/DiscordRPC.kt`): the `APPLICATION_ID`
  and `PROJECT_URL` constants still point at the original developer's
  registered Discord application and GitHub repo. Register your own app at
  https://discord.com/developers/applications and swap the ID in, or Discord
  will still show the presence as belonging to the upstream project.
- **In-app update checker** (`data/AppUpdateChecker.kt`): still checks GitHub
  Releases on the original `kushagrasinghx/BitChord` repo. Point it at your
  own repo once you have one, or disable the check — otherwise it may offer
  users an unrelated BitChord APK.
- **About page copy**: drop your real developer bio, links, etc. into the
  `AboutInfo` object in `ui/components/AboutAshMusicDialog.kt`.

## Build verification

Steps 1–13 from your brief (builds successfully, launches, icon/splash look
right, haptics fire, About page navigates, old links are gone, etc.) all need
an actual Android Studio build + device/emulator run — that wasn't possible
here. Please run through that checklist yourself before shipping.
