package com.cams.attendance.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cams.attendance.data.Repository
import com.cams.attendance.data.entity.Role
import com.cams.attendance.data.entity.User
import com.cams.attendance.ui.Routes
import com.cams.attendance.ui.theme.DisplayFont
import com.cams.attendance.ui.theme.Ink
import com.cams.attendance.ui.theme.Marigold
import com.cams.attendance.ui.theme.Parchment
import java.text.SimpleDateFormat
import java.util.*

data class DashTile(val label: String, val route: String, val icon: ImageVector, val emphasis: Boolean = false)

@Composable
fun DashboardScreen(repo: Repository, user: User, onNavigate: (String) -> Unit) {
    val students by repo.students().collectAsState(initial = emptyList())
    val teachers by repo.teachers().collectAsState(initial = emptyList())
    val classes by repo.classes().collectAsState(initial = emptyList())

    val tiles = buildList {
        add(DashTile("Swipe Attendance", Routes.SWIPE_FILTERS, Icons.Filled.TouchApp, emphasis = true))
        add(DashTile("Mark Attendance", Routes.ATTENDANCE, Icons.Filled.CheckCircle))
        add(DashTile("Students", Routes.STUDENTS, Icons.Filled.Person))
        add(DashTile("Teachers", Routes.TEACHERS, Icons.Filled.Face))
        add(DashTile("Classes", Routes.CLASSES, Icons.Filled.List))
        add(DashTile("Reports", Routes.REPORTS, Icons.Filled.Assessment))
        if (user.role == Role.ADMIN) add(DashTile("Admin", Routes.ADMIN, Icons.Filled.Settings))
    }

    val today = remember { SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date()) }
    val greeting = remember {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        when {
            hour < 12 -> "Good morning"
            hour < 17 -> "Good afternoon"
            else -> "Good evening"
        }
    }

    Column(Modifier.fillMaxSize()) {
        // --- Hero: "Today's Register" ---
        Box(
            Modifier
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Ink, Ink.copy(alpha = 0.92f))))
                .padding(horizontal = 20.dp, vertical = 24.dp)
        ) {
            Column {
                Text(today.uppercase(), style = MaterialTheme.typography.labelLarge, color = Marigold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "$greeting,\n${user.fullName}",
                    style = MaterialTheme.typography.headlineMedium,
                    fontFamily = DisplayFont,
                    fontWeight = FontWeight.Bold,
                    color = Parchment
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    if (user.role == Role.ADMIN) "Administrator" else "Teacher",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Parchment.copy(alpha = 0.65f)
                )
            }
        }

        Column(Modifier.fillMaxSize().padding(20.dp)) {
            // --- Ledger stat row ---
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Students", students.size.toString(), Icons.Filled.Person, Modifier.weight(1f))
                StatCard("Teachers", teachers.size.toString(), Icons.Filled.Face, Modifier.weight(1f))
                StatCard("Classes", classes.size.toString(), Icons.Filled.List, Modifier.weight(1f))
            }

            Spacer(Modifier.height(24.dp))
            Text("Quick Actions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(tiles) { tile -> DashboardTile(tile, onNavigate) }
            }
        }
    }
}

@Composable
private fun DashboardTile(tile: DashTile, onNavigate: (String) -> Unit) {
    val bg = if (tile.emphasis) Marigold else MaterialTheme.colorScheme.surfaceVariant
    val fg = if (tile.emphasis) Ink else MaterialTheme.colorScheme.onSurfaceVariant

    ElevatedCard(
        onClick = { onNavigate(tile.route) },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = bg),
        modifier = Modifier.fillMaxWidth().height(96.dp)
    ) {
        Column(
            Modifier.fillMaxSize().padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(tile.icon, contentDescription = tile.label, tint = fg, modifier = Modifier.size(26.dp))
            Text(
                tile.label,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = fg
            )
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, icon: ImageVector, modifier: Modifier = Modifier) {
    ElevatedCard(modifier, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) {
            Box(
                Modifier.size(30.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(16.dp))
            }
            Spacer(Modifier.height(8.dp))
            Text(
                value,
                style = MaterialTheme.typography.headlineSmall,
                fontFamily = com.cams.attendance.ui.theme.DataFont,
                fontWeight = FontWeight.Bold
            )
            Text(label, style = MaterialTheme.typography.bodySmall)
        }
    }
}
