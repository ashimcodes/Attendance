package com.cams.attendance.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.cams.attendance.data.Repository
import com.cams.attendance.ui.theme.DisplayFont
import com.cams.attendance.ui.theme.Ink
import com.cams.attendance.ui.theme.Marigold
import com.cams.attendance.ui.theme.Parchment
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(repo: Repository, onLoginSuccess: (com.cams.attendance.data.entity.User) -> Unit) {
    var username by remember { mutableStateOf("admin") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Ink, Color(0xFF20243A)),
                    startY = 0f, endY = 900f
                )
            )
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(28.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Wax-seal emblem
            Box(
                Modifier.size(76.dp).clip(CircleShape).background(Marigold),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "C",
                    fontFamily = DisplayFont,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.headlineLarge,
                    color = Ink
                )
            }
            Spacer(Modifier.height(20.dp))
            Text(
                "CAMS",
                fontFamily = DisplayFont,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.headlineLarge,
                color = Parchment
            )
            Text(
                "The Class Attendance Register",
                style = MaterialTheme.typography.bodyMedium,
                color = Parchment.copy(alpha = 0.7f)
            )
            Spacer(Modifier.height(36.dp))

            ElevatedCard(
                modifier = Modifier.fillMaxWidth().widthIn(max = 420.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = Parchment)
            ) {
                Column(Modifier.padding(24.dp)) {
                    Text(
                        "Sign in",
                        style = MaterialTheme.typography.titleLarge,
                        color = Ink,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Enter your credentials to open today's register",
                        style = MaterialTheme.typography.bodySmall,
                        color = Ink.copy(alpha = 0.6f)
                    )
                    Spacer(Modifier.height(20.dp))

                    OutlinedTextField(
                        value = username, onValueChange = { username = it; error = null },
                        label = { Text("Username") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = password, onValueChange = { password = it; error = null },
                        label = { Text("Password") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    error?.let {
                        Spacer(Modifier.height(10.dp))
                        Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(Modifier.height(20.dp))

                    Button(
                        onClick = {
                            loading = true
                            scope.launch {
                                val user = repo.login(username.trim(), password)
                                loading = false
                                if (user != null) {
                                    repo.logAction(user.id, "login", "user", user.id)
                                    onLoginSuccess(user)
                                } else {
                                    error = "Invalid username or password"
                                }
                            }
                        },
                        enabled = !loading,
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Ink, contentColor = Parchment)
                    ) {
                        if (loading) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Parchment, strokeWidth = 2.dp)
                        } else {
                            Text("Enter Register", fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.width(8.dp))
                            Icon(Icons.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            Text(
                "Default admin login: admin / admin123",
                style = MaterialTheme.typography.labelMedium,
                color = Parchment.copy(alpha = 0.5f)
            )
        }
    }
}
